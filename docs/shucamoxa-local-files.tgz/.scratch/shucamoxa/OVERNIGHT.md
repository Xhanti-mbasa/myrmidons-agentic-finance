# Overnight run rules (Thu 12 Nov to Fri 13 Nov 2026)

Cam is asleep. These rules override the ticket workflow where they differ. Never commit this file.

## Decisions Cam made for tonight
- Scope: W1 tickets only (T01-T17, skipping T18 and T19). Never touch W2-W6 work or teammates' branches
  (codex/shucamoxa-mcp, feat/team-access-model-versioning, or any branch you didn't create).
- Landing: each ticket is squash-merged to main once CI and the independent review pass. T03 merges
  too, even though the squad hasn't approved it; its PR body says "Merged overnight at Cam's request,
  pending squad review."
- Contract: keep the spec's pay(supplierId, amount, invoiceNumber, reason). Xhanti's MCP gateway
  (pay_invoice(invoice_id, reason), /v1 routes) is a known conflict that gets a morning write-up. Don't
  change code to match it.

## Roles
- BUILDER: vets the ticket, builds it test-first on its branch, verifies, squashes to ONE local commit,
  and writes the PR body. The builder NEVER pushes, opens PRs or merges.
- REVIEWER: a fresh agent that reviews the branch read-only and approves or lists required changes.
- ORCHESTRATOR (main session): pushes, opens the PR, waits for CI, squash-merges, and logs progress.

## Vet before building (builder step 0)
Read the ticket as a senior TypeScript and XRPL engineer. Ask: is the approach correct, secure, and
consistent with the spec and with what is on main now? Fix flaws inside the ticket's intent and record
each deviation under "Deviations from the ticket" in the PR body. If the ticket can't be done safely,
needs a human decision, needs network access we don't have (the model laptop, testnet funds), or
conflicts with a teammate's work, stop and report BLOCKED with the reason. Don't guess.

## Environment facts
- Repo: /home/claude/myrmidons-agentic-finance (a shallow clone). Refresh main with
  `git fetch --depth=50 origin main`, then branch from origin/main.
- Node 22 and pnpm 10 are installed. Package installs from npm work. Other network access mostly doesn't.
- The model server (teammate's laptop over Tailscale) is NOT reachable. Never run real-model evals or the
  smoke test. Unit tests use scripted models.
- No testnet transactions, ever, tonight.
- gitleaks can't be installed here. Run `/home/claude/tools/seedscan.sh` instead (it also checks that no
  local-only file is tracked). CI runs real gitleaks once T02 is merged.
- T01 sources: archive at /home/claude/untrusted/tests_a/repo, smoke test at
  /home/claude/untrusted/handoff/model-smoke-test.ts.
- `gh` needs `env -u GH_TOKEN gh ...` (orchestrator only).

## Commit format (builder's single squashed commit)
Subject: the ticket's "Commit subject" line. Body: what changed, tests added. End with exactly:

    Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
    Claude-Session: https://claude.ai/code/session_01QvHtf15a2gsPJxPDQ4HZNR

## PR body file
Write .scratch/shucamoxa/pr/TNN.md with: Summary, Tests added (with counts), Mutations checked (each
mutation and which test went red), Security notes, Deviations from the ticket, Follow-ups. End with:

    🤖 Generated with [Claude Code](https://claude.com/claude-code)

    https://claude.ai/code/session_01QvHtf15a2gsPJxPDQ4HZNR

## Hard stops
Never: push, merge, force-push main, delete branches you didn't create, weaken or skip a test, commit a
secret or a local-only path, add an "allow unsafe" switch, or call any external service except the npm
registry.
