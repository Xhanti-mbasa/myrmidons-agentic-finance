# Payment contract conflict: spec vs Xhanti's MCP gateway

Written overnight, 12-13 Nov 2026. A decision for the squad; nothing in the code was changed to match either side.

## The two contracts

| | Spec (what the W1 agent builds to) | Xhanti's `codex/shucamoxa-mcp` branch |
| --- | --- | --- |
| Pay call | `pay(supplierId, amount, invoiceNumber, reason)` | `pay_invoice(invoice_id, reason)` |
| Who supplies the amount and supplier at pay time | The agent (bound by code to its own extraction, after T04/T06) | The backend, from a stored invoice record |
| Transport | REST from the agent's own TypeScript tool loop | MCP over stdio (Python, FastMCP); the agent harness must be an MCP client |
| Routes | `GET /rules`, `GET /suppliers`, `POST /payments`, `POST /approvals`, `GET /log` | `GET /v1/mandate`, `/v1/balance`, `/v1/invoices/{id}`, `POST /v1/invoices/{id}/payment`, `GET /v1/invoices/{id}/payment` |
| Retry safety | Idempotent on invoiceNumber (server-side) | `Idempotency-Key` header plus `get_payment_status` and an explicit `unknown` outcome |
| Proposals and approvals | `propose_supplier`, `request_approval` | None yet |
| Audit log questions | `query_log` | None yet |

## Assessment

Xhanti's design is stronger on one point that matters: the model can't choose the amount or supplier when it pays. The backend uses what's stored against the invoice ID. It also handles "the payment outcome is unknown" better than the spec does.

It doesn't remove the hardest problem, it moves it. Someone still has to turn an uploaded PDF into a stored invoice record (supplier, amount). If that's the agent's extraction step, the stored record is only as trustworthy as the extraction, which is the G5 finding. T06's grounding checks are needed either way.

Adding MCP plus a second language (Python) to the agent's path costs time we don't have before Friday 18:00, and the agent doesn't need MCP to get the benefit.

## Recommendation (hybrid, about 2 hours of W1 work)

1. Keep REST and TypeScript for the agent's tools.
2. Adopt invoice-ID binding: after extraction and grounding, the agent service's code (not a model tool) registers the invoice with the backend: `POST /invoices {invoiceNumber, supplierId, amount, extractedFrom}`. The backend stores it.
3. Change the model's tool to `pay(invoiceNumber, reason)`. The payment service reads supplier and amount from the stored invoice, so the policy service can also check the request against it.
4. Take three things from Xhanti's gateway: the `Idempotency-Key` header, the `unknown` payment status, and a `get_payment_status` read tool.
5. Keep Xhanti's MCP gateway as the optional "any MCP agent can use Shucamoxa" integration in the roadmap, not the demo path.

If the squad agrees, this becomes a new W1 ticket (T39) plus small edits to T26 (payment service) and T30 (API). Merged W1 tickets don't block it: the change is in `tools.ts`, `backend.ts` and `@shucamoxa/shared`.

## Also noticed

- Xhanti's `feat/team-access-model-versioning` branch changes `.gitignore` and `README.md` and adds a Python CI workflow. Both of his branches started from the old `main`, so they'll need a rebase onto the new `main`. The conflicts are small (`.gitignore`, `README.md`).
- His team doc describes a shared Linux "model instance" with SSH accounts. If the model moves there from the laptop, the agent only needs a new `MODEL_BASE_URL`. The Tailscale-only and no-public-port rules still apply.
