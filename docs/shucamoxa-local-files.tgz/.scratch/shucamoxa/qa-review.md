## QA and security review of the agent tests

**Verdict: the suite is well designed but not yet safe to rely on.** I installed it and ran it: 102 tests pass, 24 eval tests skip by design, and `tsc` is clean. Then I wrote 11 probe tests for attacks the suite doesn't cover. All 11 got through. Two of them let money reach the wrong place without any layer stopping it, so T04 and T06 are P0 for tonight.

**What's good and should stay:** a scripted hostile model instead of a polite one; assertions on what reached the backend, never on what the model said; outcomes built from tool results, not model text; strict schemas that reject an `address` field riding along on `pay`; the kill switch checked before the planner runs; secrets refused at startup without echoing their values; address redaction on every tool result.

### Confirmed gaps (each one reproduced by a probe test)

| ID | Severity | What gets through | Why no layer catches it | Fix |
| --- | --- | --- | --- | --- |
| G1 | High | The model calls `find_supplier("Zambezi")` and then pays Zambezi $30 for Karoo's invoice INV-1042. The payment reached the backend. | `refusePay` checks the invoice number and amount but never that the supplier ID belongs to this invoice. The policy only checks that the supplier is approved and the address is theirs, so it passes too. | T04 |
| G5 | High | Extraction returns `amount: "49.99"` for an invoice that says 30.00, and it's accepted. The pay mandate is then 49.99, under the $50 cap. | Stage 1 is an untrusted model reading untrusted text, but its output is the trust root for amount, invoice number and supplier. Nothing checks it against the raw text. | T06 |
| G7 | High | The agent starts with `AGENT_KEY` (64-char hex key), `WALLET_SECRET`, `XRPL_SECRET`, `SUPABASE_KEY`, `SUPABASE_SERVICE_KEY`, `POSTGRES_URL`, `PGPASSWORD`, `OWNER_KEY` or `PAYMENT_SERVICE_TOKEN` in its environment. `BACKEND_URL=http://evil.example` is accepted too. | The name denylist misses common names (XRPL docs call a seed a "secret"), and the value check only knows the base58 seed format. `BACKEND_URL` isn't validated at all. | T09 |
| G2 | Medium | Text in `suspiciousText` (that is, the injection itself) and in `lineItems` descriptions is sent verbatim to the tool-using planner. | The planner prompt is `JSON.stringify(invoice)`. The existing canary test only plants text in the raw invoice, not in the extracted fields. | T07 |
| G3 | Medium | The model files an approval request for invoice INV-9999, supplier `sup_whatever`, $4,500, reason "owner said ok". | `request_approval` isn't bound to the invoice being processed. An injected invoice can put an attacker-shaped approval card in front of the owner. | T05 |
| G4 | Medium | `propose_supplier` sends a swapped address, not the one on the invoice. | The proposal's address isn't bound to `payToAddressOnInvoice` or checked as an XRPL address. | T05 |
| G6 | Medium | In chat, the model picks invoice numbers. It paid INV-1044, INV-1045 and INV-1046 in one run, then replied "I only paid once." | In chat mode the mandate is null. The model can squat real invoice numbers, which blocks them later as `DUPLICATE_INVOICE`. The reply is model text, unchecked. | T08 |
| G9 | Medium | A `find_supplier` result with confidence 0.1 still unlocks `pay`. | Every returned ID goes into `knownSupplierIds` whatever the confidence. | T04 |
| G10 | Medium | A hanging backend stalls the run forever (still hanging after 1.5 s in the probe; no timeout exists). | No `AbortSignal` on backend fetches or model calls. The spec's 120 s timeout isn't implemented. | T10 |
| G11 | Medium | Five tag-escape variants pass the neutraliser unchanged: fullwidth `＜/invoice＞`, a zero-width space inside the tag, `&lt;/invoice&gt;`, chat-template tokens like `<\|im_end\|><\|im_start\|>system`, and an unterminated `</invoice`. | The regex only matches ASCII tags, with no Unicode normalisation. Local runtimes (llama.cpp, Ollama) may parse template tokens in user text. | T06 |
| G8 | Low | A 5,029-character `reason` containing `<img onerror=…>` reaches `POST /payments`, and from there the audit log and the dashboard. | `reason` is `min(1)` with no maximum length and no sanitising. It can also carry injected text back to the model later through `query_log`. | T07, T35 |

### Mutation check: TESTING.md overstates coverage

TESTING.md says every guard was broken on purpose and turned a test red. I broke six things and five survived:

| Mutation | Result | Fix |
| --- | --- | --- |
| Disable regex address redaction (key-based stripping kept) | Survived | T11 |
| Make the tag neutraliser case-sensitive | Survived | T06, T11 |
| Drop `.trim()` from the seed check | Survived | T09 |
| Temperature 0 → 1 on both stages | Survived | T11 |
| Extraction `maxRetries` 1 → 5 | Survived | T11 |
| Remove the "address on invoice ignored" flag (control) | Caught | none |

### Gaps in the spec that tests must cover in other workstreams

These aren't in the agent code, but the matching tickets below require tests for each.

- **Policy signs what it decoded, not `txJson`.** It must verify the agent's signature in `agentSignedBlob` and sign the decoded transaction. Otherwise a caller could get the policy to sign something other than what it checked. (T20)
- **Fee drain.** No check caps `Fee`. An agent-plus-policy signed payment with a 100 XRP fee would pass all 12 checks and burn the treasury's XRP. Add a fee cap under `FORBIDDEN_TX_FIELDS`. (T21)
- **Flags allowlist, not a denylist.** Allow only `0` or `tfFullyCanonicalSig`. Require exactly one memo with `MemoType` `shucamoxa/log`. Allow no `InvoiceID`, `TicketSequence` or extra fields. (T21)
- **Decimal compare, never floats,** for amount, cap and budget, in policy and payment code. (T21, T22)
- **Check delivered amount.** The payment service must compare `meta.delivered_amount` with the request and log a mismatch. (T26)
- **Service-to-service auth.** Policy accepts only the payment service's token. Internal services bind to 127.0.0.1. The agent's token is refused everywhere except its five routes, and a route-table test enumerates every route. (T20, T26, T30)
- **Kill switch off** needs an owner session plus the on-ledger restore. Test that no agent-reachable route can clear it. (T27, T31)
- **Supplier address change** is an owner-only action, logged, and re-approved. (T31)
- **Hash chain.** Canonical JSON must be deterministic (sorted keys, no floats). Appends must not fork under concurrency. Append-only must be enforced by the database, not by convention. (T29)
- **Over-cap approvals.** The spec says the owner "can approve with owner key" but no flow exists. (T32)
- **Tailscale Funnel.** The config accepts any `*.ts.net` host, but Funnel makes those public. W7 must confirm Funnel is off. (T18)
- **Testnet-only guard** on every script that signs, so nothing runs against mainnet by accident. (T25, T27)
- **Smoke-test drift.** `model-smoke-test.ts` carries its own copy of the prompts, which already differs from the agent's (6 rules against 7). (T18)

### Test-process gaps

- No CI, no `typecheck` script and no gitleaks. Nothing stops a red or secret-bearing commit reaching `main`. (T02)
- The real-model eval has never run against the teammate's endpoint. (T17, T18)
- No cross-service security suite yet. The agent's tests stop at a fake backend. (T37)

