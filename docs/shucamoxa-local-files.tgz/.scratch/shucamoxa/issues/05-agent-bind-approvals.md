# T05 · Bind approvals and supplier proposals to the invoice (G3, G4)

Status: resolved
Blocked by: 04
Branch: fix/t05-agent-bind-approvals
Owner: Cam
Priority: P0
Due: Fri 01:30

**Branch** `fix/t05-agent-bind-approvals` · **Owner** Cam · **P0** · **Depends on** T04 · **Due** Fri 01:30

**Why:** an injected invoice can currently put a $4,500 approval card, or a supplier proposal carrying an attacker's address, in front of the owner. Owners click approve on things that look routine, so the cards must carry only what the invoice actually says.

**Acceptance criteria**

- [ ] In invoice mode, `request_approval` is refused unless `invoiceNumber`, `amount` and `supplierId` all equal the mandate's. The amount must also actually be over the cap or remaining budget, compared in cents from `get_rules`.
- [ ] In invoice mode, `propose_supplier` is refused unless `name` equals the extracted `supplierName` and `address` equals `payToAddressOnInvoice` (or both are null). The address must pass `XrplAddress`. The tool adds `invoiceNumber` from the mandate itself.
- [ ] Calling `propose_supplier` when the mandate already has a supplier is refused.
- [ ] At most one approval of each kind per run.
- [ ] In chat mode, `request_approval` needs a `supplierId` the backend returned at or above the threshold. `propose_supplier` is unavailable in chat (owners add suppliers on the dashboard).
- [ ] The approval payload sent to `POST /approvals` parses as `ApprovalRequest`.

**Tests:** the G3 and G4 probes as failing tests (zero rows in `backend.approvals`); a second `request_approval` in the same run is refused; a valid over-cap request is accepted; an under-cap `request_approval` is refused; a valid unknown-supplier proposal carries exactly the invoice's address.

**Prompt**

```text
Ticket T05: bind request_approval and propose_supplier to the invoice being processed.
Follow the Shucamoxa ticket workflow in CLAUDE.md. Branch: fix/t05-agent-bind-approvals.

The gaps (both reproduced):
- G3: in invoice mode the planner can call request_approval({invoiceNumber: "INV-9999",
  supplierId: "sup_whatever", amount: "4500.00", reason: "owner said ok"}) and it reaches POST /approvals.
- G4: propose_supplier sends any address the model chooses, not the address on the invoice.
An injected invoice can therefore put an attacker-shaped approval card in front of the owner.

Failing tests first (agent-run.test.ts and chat.test.ts), asserting on backend.approvals:
1. G3 as above -> zero approvals.
2. request_approval for the invoice's own number, amount and supplier, when the amount is UNDER the
   cap -> zero approvals (pay is the right tool).
3. Over-cap invoice (INV-2001, 120.00, sup_karoo) -> exactly one approval, kind "payment", payload equal
   to the mandate.
4. A second request_approval in the same run -> still exactly one.
5. G4: unknown supplier invoice, propose_supplier with address rAttackerSwapped44444444444444 -> zero
   approvals.
6. propose_supplier with name and address exactly as extracted -> one approval whose payload includes
   the mandate's invoiceNumber, and whose body parses as ApprovalRequest.
7. propose_supplier when the mandate already has a supplierId -> zero approvals.
8. chat(): propose_supplier is not among the offered tools; request_approval with a supplierId that
   find_supplier never returned -> zero approvals.

Implement in src/tools.ts (and RunState): keep the extracted supplierName and payToAddressOnInvoice in
the mandate; add refusal functions for both tools mirroring refusePay; compare amounts with toCents from
@shucamoxa/shared (cap and remaining come from the get_rules result the code already read, not from the
model); validate addresses with XrplAddress; allow one approval per kind per run; build chat tools
without propose_supplier. Refusals go back to the model as {refused: true, reason}, never as exceptions.

Update the decide() logic only if a test proves it's needed. Run the break-it check on every new guard.
Commit subject: fix(agent): bind approval requests and supplier proposals to the invoice (T05)
```

## Comments
