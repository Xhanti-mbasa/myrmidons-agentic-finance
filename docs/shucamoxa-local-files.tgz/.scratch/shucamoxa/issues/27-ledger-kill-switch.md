# T27 · On-ledger kill switch and revocation proof

Status: ready-for-agent
Blocked by: 25, 31
Branch: feat/t27-ledger-kill-switch
Owner: W3
Priority: P0
Due: Fri 15:00

**Branch** `feat/t27-ledger-kill-switch` · **Owner** W3 · **P0** · **Depends on** T25, T31 · **Due** Fri 15:00

**Why:** "the ledger itself rejects the agent" is the strongest moment in the demo. One detail the spec leaves out: with the master key disabled, the owner's `SignerListSet` must itself be multisigned, with the owner as the only signer, which works because weight 2 meets quorum 2.

**Acceptance criteria**

- [ ] `scripts/kill-switch.ts revoke` builds a `SignerListSet` with quorum 2 and entries for policy (weight 1) and owner (weight 2), with no agent. The owner signs in multisign mode, `multisign([ownerBlob])` combines it, and it's submitted. The script prints the hash and logs `signer_list_changed` through the owner API (T31).
- [ ] `scripts/kill-switch.ts restore` puts back agent 1, policy 1 and owner 2. It refuses to run while the database kill-switch flag is on, so the owner clears the flag on the dashboard first, deliberately.
- [ ] `scripts/prove-revocation.ts` builds a normal payment, signs it directly with the agent and policy keys (bypassing the policy service), submits it, and asserts the engine result isn't `tesSUCCESS` (expect `tefBAD_SIGNATURE` or similar). It prints the result for the camera.
- [ ] All three scripts refuse non-testnet. The owner seed is read only from `secrets/owner-dev.env` (or Xaman, if the squad chooses it).
- [ ] The same builder functions are exported for the dashboard to show the unsigned transaction if the owner signs with a wallet app.

**Tests:** the builders, offline (revoke has no agent entry, restore has all three); a quorum test proving agent plus policy weight is below quorum after revoke and owner alone meets it; `restore` refuses while the flag is on; mainnet is refused; no seed in output. An optional `RUN_TESTNET=1` test runs revoke, the proof, then restore.

**Prompt**

```text
Ticket T27: on-ledger kill switch (revoke/restore the agent key) and a revocation proof for the demo.
Follow the Shucamoxa ticket workflow in CLAUDE.md. Branch: feat/t27-ledger-kill-switch.

Read .scratch/shucamoxa/spec.md "Kill switch" and demo scenario 6. The treasury's master key is disabled,
so a SignerListSet from the treasury must itself be MULTISIGNED: the owner signs with
wallet.sign(tx, true) and you submit multisign([ownerBlob]); owner weight 2 meets quorum 2.

Tests first (scripts/test/kill-switch.test.ts, offline):
1. buildRevoke({policy, owner}) -> SignerQuorum 2, entries policy 1 and owner 2, no agent;
   buildRestore({agent, policy, owner}) -> agent 1, policy 1, owner 2.
2. Quorum maths helper: after revoke, weight(agent + policy) < quorum and weight(owner) >= quorum.
3. restore refuses when the API reports killSwitch true (inject the API client).
4. assertTestnet refuses mainnet; stdout never contains OWNER_DEV_SEED, AGENT_SEED or POLICY_SEED.
5. prove-revocation's result check: tesSUCCESS -> exits non-zero with "REVOCATION FAILED"; any tef or tem
   code -> prints it and exits 0.

Implement scripts/kill-switch.ts (revoke | restore) and scripts/prove-revocation.ts with tsx. Read seeds
only from secrets/owner-dev.env, services/payment/.env and services/policy/.env as needed; never print
them. After a successful revoke or restore, POST the tx hash to the owner API's signer-list endpoint (T31)
with the owner session token from OWNER_API_TOKEN so the activity log records signer_list_changed. Export
the builders from a small package (packages/xrpl-tx or scripts/lib) so the dashboard can show the unsigned
tx. Add an opt-in RUN_TESTNET=1 test: revoke -> prove -> restore, and tell me before running it.
Commit subject: feat(xrpl): owner-signed on-ledger revocation and a direct-submit proof (T27)
```

## Comments
