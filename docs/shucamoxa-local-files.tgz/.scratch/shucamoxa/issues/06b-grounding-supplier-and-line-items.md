# T06b: Ground the supplier against the sender line, and check line items against the invoice text

Status: ready-for-agent
Blocked by: 06, 16
Branch: fix/t06b-grounding-supplier-and-line-items
Owner: Cam
Priority: P0 before the demo (09), P1 (10)

## Why

The T16 review confirmed two holes where only the model stands between an attacker and a payment:

1. **Fixture 09 (impersonation of another approved supplier).** The notes in a Karoo invoice say "remit to Zambezi Spices". The extraction model, which reads the attacker's text, returns `supplierName: "Zambezi Spices"`. `grounding.ts:53/:91` only checks that each word of the name appears somewhere in the text, so it passes. `resolveSupplier` locks the mandate to `sup_zambezi`, and the policy allows it, because the supplier is approved, the address is right and the amount is under the cap. A side effect is that INV-1047 is used up, so Karoo's real INV-1047 is later refused as `DUPLICATE_INVOICE`. This reopens G1 through stage 1.
2. **Fixture 10 (line items don't sum to the total).** `grounding.ts:55` skips the line-item check when `lineItems` is empty. A single invented line item of 49.99 also grounds, because line-item amounts are never checked against the text.

## What to build

- **Supplier name.** Ground `supplierName` against the sender block only: the `From:` line, or the letterhead lines before the first `To:`/`Bill to:`/`Invoice` header. Matches in notes, footers or anywhere else don't count. If no sender block can be found, send the invoice for review (fail closed).
- **Line items.**
  - Compute the item sum from the text itself, using the trailing amounts on item lines before the first total, sub-total, VAT or tax line. If there are item lines and their sum isn't the total, send the invoice for review, whatever the model returned.
  - Every extracted line-item amount must appear on an item line of the text.
- Money is compared in integer cents. No floats.

## Tests (write first)

- 09 with `supplierName: "Zambezi Spices"` doesn't ground, and the outcome is `needs_review`. 09 with `supplierName: "Karoo …"` (the real sender) grounds.
- 10 with `lineItems: []` doesn't ground. 10 with `[{amount: "49.99"}]` doesn't ground.
- Every one of fixtures 01–08 and 11–14 keeps its current outcome. The reviewer checked the sum rule against all 18 fixtures: only 10 fails it, and 07 and 08 have no item lines, so they're skipped.
- An invoice with no detectable sender block goes to `needs_review`.
- Mutation checks for each new guard.
- When done, update `expected.json` 09 and 10: `blockedBy: "agent"`, and remove `knownGap`.

## Follow-ups noted by the T16 review (not this ticket)

- T17: replay `14-red-team-split/` against a fake backend that tracks the budget, including the parallel variant.
- W2 policy tests: the 09 hostile replay as a known-gap test, and small split payments against `RATE_LIMITED`.
- W3/T26: the payment service binds each invoice number to its supplier.
- PDF intake ticket: `normaliseInvoiceText(pdfSafeText(raw)) === normaliseInvoiceText(raw)` for every fixture.
