# T32 · Owner-signed over-cap payment path

Status: ready-for-agent
Blocked by: 26, 31
Branch: feat/t32-owner-approved-payment
Owner: W4 + W3
Priority: P1
Due: Fri 14:00

**Branch** `feat/t32-owner-approved-payment` · **Owner** W4 and W3 · **P1** · **Depends on** T26, T31 · **Due** Fri 14:00

**Why:** demo scenario 3 says "owner can approve with owner key", but no flow exists yet. The owner's weight of 2 meets quorum alone, so this path skips the agent and the policy on purpose: it is the human's authority, not the agent's.

**Acceptance criteria**

- [ ] Approving a payment approval makes the API build an unsigned `Payment` (the T26 builder; memo hash of a new `approval_decided` entry) for exactly the approved invoice, supplier and amount, and return it to the dashboard.
- [ ] The owner signs it: `scripts/owner-sign.ts <approvalId>` with the dev seed, or a wallet app (decision D4). The signed blob goes back to `POST /owner/approvals/:id/submit`, which checks it is the same transaction signed by the owner key before submitting.
- [ ] Each approval can be executed once. The result is recorded as a settled reservation marked `owner`, so it counts toward the budget, and logged as `payment_settled` with actor `owner`.
- [ ] The agent token can't reach any of it. The owner seed never touches the API or web processes.

**Tests:** the unsigned transaction matches the approval exactly; a blob signed by any other key, or for a different transaction, is refused; a second submit of the same approval is refused; the budget counts the owner payment; the agent token gets 403.

**Prompt**

```text
Ticket T32: let the owner approve and sign an over-cap payment (demo scenario 3), outside the agent.
Follow the Shucamoxa ticket workflow in CLAUDE.md. Branch: feat/t32-owner-approved-payment.

The owner's signer weight is 2 and the quorum is 2, so the owner alone can sign. This path deliberately
skips the agent and the policy service: it's the owner's own authority. Reuse T26's payment builder.

Tests first (services/api/test/owner/approved-payment.test.ts, offline signing):
1. Approving a payment approval for INV-2001 / sup_zambezi / 120.00 returns an unsigned tx whose
   Destination, Amount and memo match exactly; an approval_decided entry is logged and its hash is the memo.
2. POST /owner/approvals/:id/submit with the owner's multisign blob of that tx -> submitted (fake client),
   recorded as a settled reservation with source "owner", and payment_settled logged with actor owner.
3. A blob signed by the agent or policy key, or for a different Amount -> 400, nothing submitted.
4. Submitting the same approval twice -> the second gets 409.
5. After the owner payment, GET /rules shows spent including 120.00.
6. The agent token -> 403 on both routes.

Implement the two routes and scripts/owner-sign.ts <approvalId> (reads OWNER_DEV_SEED from
secrets/owner-dev.env only, fetches the unsigned tx with OWNER_API_TOKEN, signs with wallet.sign(tx,
true), posts the blob back). The API never holds the owner seed. Refuse non-testnet everywhere.
Commit subject: feat(api): owner-signed execution of approved over-cap payments (T32)
```

## Comments
