# T35 · Kill switch and activity screen with the "log intact" badge

Status: ready-for-agent
Blocked by: 27, 29, 33
Branch: feat/t35-web-killswitch-activity
Owner: W5
Priority: P0
Due: Fri 15:00

**Branch** `feat/t35-web-killswitch-activity` · **Owner** W5 · **P0** · **Depends on** T27, T29, T33 · **Due** Fri 15:00

**Why:** the demo ends on this screen, and it's where the owner investigates mistakes: invoice, reason, decision and ledger result, verifiable against the chain.

**Acceptance criteria**

- [ ] A kill-switch control on every page. Turning it on is one click, takes effect at once, and logs the event. The page then shows the ledger step (the `pnpm kill-switch revoke` command, or the unsigned `SignerListSet` for a wallet app) and the `signer_list_changed` hash once it's recorded.
- [ ] Resume needs the owner to type `RESUME` and states that the on-ledger restore comes first.
- [ ] **Activity screen:** newest first, polled every 3 s. Each row shows time, event, invoice, supplier, amount, rule code, the fixed explanation, ledger result, and a tx link to `https://testnet.xrpl.org/transactions/<hash>`, built only when the hash matches `^[0-9A-F]{64}$`.
- [ ] On load and on every poll, the browser runs `verifyChain` from `@shucamoxa/shared` over the entries and shows "Log intact" or "Log broken at #n". The badge is computed in the browser, not taken from the server's word.
- [ ] Suspicious invoice text and model-written reasons appear in a clearly labelled "untrusted text" box, as plain text.

**Tests:** the badge shows intact for a valid chain and "broken at #3" when row 3 is altered; no link is built for a malformed hash, for `javascript:` or one containing quotes; XSS text renders literally; the kill-switch button posts and the UI reflects the new state; resume is disabled until `RESUME` is typed.

**Prompt**

```text
Ticket T35: kill switch control and the activity screen with an in-browser "log intact" check.
Follow the Shucamoxa ticket workflow in CLAUDE.md. Branch: feat/t35-web-killswitch-activity.

Read .scratch/shucamoxa/spec.md "Kill switch", "Hash chain" and "Recording checklist".

Tests first (Testing Library):
1. Activity: given a valid chain of 5 entries -> "Log intact"; alter entry 3's amount -> "Log broken at #3".
   The badge comes from verifyChain in @shucamoxa/shared run in the component, never from a server field.
2. Explorer links: a 64-char uppercase hex hash -> link to https://testnet.xrpl.org/transactions/<hash>;
   "javascript:alert(1)", a hash with a quote, and a 63-char hash -> no link, text only.
3. Untrusted text (explanation, reason, suspiciousText) containing HTML renders literally inside a box
   labelled "Untrusted text from the invoice or agent".
4. Kill switch: clicking posts {on: true} and the UI shows "Agent payment authority revoked" plus the
   ledger step (the revoke command, or the unsigned SignerListSet from the T27 builders per decision D4);
   once the log has signer_list_changed, its tx hash links to the explorer.
5. Resume is disabled until the owner types RESUME, and says to run the on-ledger restore first.

Implement the kill-switch control in the layout and the Activity page (poll GET /api/log every 3 s,
newest first, plus the fields in the ticket).
Commit subject: feat(web): kill switch control and activity screen with in-browser chain check (T35)
```

## Comments
