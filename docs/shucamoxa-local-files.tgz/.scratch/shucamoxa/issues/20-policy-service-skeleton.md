# T20 · Policy service: skeleton, auth, decode and verify

Status: ready-for-agent
Blocked by: 03
Branch: feat/t20-policy-service-skeleton
Owner: W2
Priority: P0
Due: Fri 10:00

**Branch** `feat/t20-policy-service-skeleton` · **Owner** W2 · **P0** · **Depends on** T03 · **Due** Fri 10:00

**Why:** the spec says the policy service decodes `agentSignedBlob` itself. Two more things make that safe: checking the agent's signature is genuine and by the agent key, and signing the decoded transaction rather than the caller's `txJson`.

**Acceptance criteria**

- [ ] `services/policy` is a Hono app on `POLICY_HOST` (default `127.0.0.1`) and `POLICY_PORT` (default `8791`) with `GET /health` and `POST /cosign`.
- [ ] `POST /cosign` requires `Authorization: Bearer <POLICY_CALLER_TOKEN>` (only the payment service has it), compared in constant time. Bodies over 64 KB get 413. The body must parse as `CosignRequest`.
- [ ] Env: `POLICY_SEED`, `POLICY_CALLER_TOKEN`, `AGENT_ACCOUNT`, `TREASURY_ACCOUNT`, `XRPL_WSS`. Startup refuses a non-testnet `XRPL_WSS` and refuses to start if `POLICY_SEED` derives `AGENT_ACCOUNT` (keys must differ).
- [ ] Decode and verify: `agentSignedBlob` decodes; it has exactly one `Signers` entry; that signer's `Account` is `AGENT_ACCOUNT`; its `SigningPubKey` derives that address; the signature verifies over `encodeForMultisigning(tx, AGENT_ACCOUNT)`; `SigningPubKey` on the transaction is `""`. Any failure blocks with `FORBIDDEN_TX_FIELDS`.
- [ ] The decoded transaction, minus `Signers`, must deep-equal `txJson` (compared with `canonicalJson`). A mismatch blocks.
- [ ] A check pipeline: an ordered array of pure functions `(ctx) => RuleCode | null` where the first failure wins. T20 ships checks 1 (kill switch) and 2 (type and account). The rest arrive in T21 to T23.
- [ ] On allow, the service signs the **decoded** transaction with `wallet.sign(tx, true)` and returns `policySignedBlob`.
- [ ] Any exception gives `block` with a generic reason (fail closed), never a 500 that the caller might retry.
- [ ] Rules come through a `RulesReader` interface: in memory for tests, the database in T22.

**Tests** (`services/policy/test/cosign.test.ts`, all offline with generated wallets): a valid agent-signed payment is allowed and the returned blob combines with the agent's via `multisign` into a transaction with two valid signers; no token, the agent backend token, or the wrong token all get 401; a blob signed by a different key, a blob with two signers, a blob whose `txJson` differs from the decoded transaction in `Amount` or `Destination`, and a single-signed (non-multisign) blob are each blocked; kill switch on gives `KILL_SWITCH_ON`; `TransactionType` `TrustSet` or `AccountSet` and an `Account` that isn't the treasury give `FORBIDDEN_TX_FIELDS`; a throwing `RulesReader` gives `block`; the service refuses to start with a mainnet URL or with matching keys.

**Prompt**

```text
Ticket T20: policy service skeleton - authenticated POST /cosign that decodes and verifies the agent's
signed blob and only ever signs the transaction it decoded.
Follow the Shucamoxa ticket workflow in CLAUDE.md. Branch: feat/t20-policy-service-skeleton.

Read .scratch/shucamoxa/spec.md "Policy service spec" and "Signing flow". Two extra requirements that the
spec implies but doesn't state, which are the point of this ticket:
- verify the agent's signature in agentSignedBlob is genuine and by AGENT_ACCOUNT;
- sign the DECODED transaction, never the caller's txJson.

Create services/policy (Hono, xrpl, @shucamoxa/shared, zod). Tests first in test/cosign.test.ts, offline,
using Wallet.generate() for treasury, agent, policy and a supplier, and building a Payment by hand (no
autofill): Sequence 1, Fee "36", LastLedgerSequence 100, the RLUSD Amount object, one memo.
1. Valid agent multisign blob -> allow; xrpl's multisign([agentBlob, policyBlob]) produces a tx with
   two Signers that both verify.
2. Auth: missing token, wrong token, or a different service's token -> 401. Body > 64 KB -> 413.
3. Blocked with FORBIDDEN_TX_FIELDS: blob signed by a non-agent key; blob with two Signers; blob with no
   Signers (single-signed); txJson whose Amount or Destination differs from the decoded blob;
   tx SigningPubKey not ""; TransactionType TrustSet; Account not the treasury.
4. killSwitch true -> KILL_SWITCH_ON (check 1 runs first).
5. RulesReader throws -> block, reason "policy check failed", no stack trace, no signature.
6. createPolicyServer refuses: XRPL_WSS not on the testnet allowlist (wss://s.altnet.rippletest.net:51233
   and the official testnet clio URL); POLICY_SEED whose address equals AGENT_ACCOUNT.
7. No log line contains POLICY_SEED or any part of it (capture the logger).

Implement:
- src/verify.ts: decode the blob, check exactly one signer equals AGENT_ACCOUNT, deriveAddress of its
  SigningPubKey equals it, verify the signature with ripple-keypairs over
  encodeForMultisigning(txWithoutSigners, AGENT_ACCOUNT), and compare canonicalJson(decoded minus
  Signers) with canonicalJson(txJson).
- src/checks.ts: type Check = (ctx) => RuleCode | null; export an ordered CHECKS array with check 1
  (kill switch) and check 2 (Payment from TREASURY_ACCOUNT). T21-T23 add the rest.
- src/server.ts: createPolicyServer(deps) with constant-time bearer auth, body limit, CosignRequest
  parsing, verify, the pipeline, then wallet.sign(decodedTx, true). Wrap everything: any exception ->
  {decision: "block", ruleCode: "FORBIDDEN_TX_FIELDS", reason: "policy check failed"}. The response must
  parse as CosignResponse.
- src/main.ts reading services/policy/.env (POLICY_SEED, POLICY_CALLER_TOKEN, AGENT_ACCOUNT,
  TREASURY_ACCOUNT, XRPL_WSS, POLICY_HOST default 127.0.0.1, POLICY_PORT default 8791) and
  services/policy/.env.example with placeholders only.
Commit subject: feat(policy): authenticated cosign service that verifies and signs only what it decoded (T20)
```

## Comments
