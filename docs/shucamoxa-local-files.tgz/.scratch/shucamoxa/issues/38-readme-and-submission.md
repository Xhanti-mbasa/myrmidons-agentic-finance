# T38 · README, recording and submission

Status: ready-for-human
Blocked by: 37
Branch: docs/t38-readme-and-submission
Owner: W6
Priority: P0
Due: Fri 23:00

**Branch** `docs/t38-readme-and-submission` · **Owner** W6 · **P0** · **Depends on** T37 · **Due** Fri 23:00 (submission closes at 23:59)

**Why:** the final submission is the title, a public repo with a README, and the demo video. Judges read the README before they watch, and every claim in it should match code they can open.

**Acceptance criteria**

- [ ] README sections, in order: the pitch line; the problem (the Cape Town importer); how it works (architecture diagram PNG, the three layers, trust zones); the six demo scenarios with real testnet tx links from `docs/demo-evidence.md`; Ripple's four MVP requirements mapped to evidence; the threat model and known limits (from the spec); how to run (setup, migrate, seed, `dev:all`, tests); security practices (no seeds in the repo, gitleaks, testnet only); the roadmap (the spec's out-of-MVP list); the team.
- [ ] Every command in the README is run once by Claude Code (except testnet-spending ones) and works as written.
- [ ] Every claim is checked against code. Anything not built is moved to the roadmap or removed.
- [ ] The recording checklist from the spec, plus the T18 smoke test run in the last 10 minutes, is ticked on paper, not in the repo.

**Human steps (ready-for-human):** make the repo public after a final `gitleaks detect` over the full history; record the video following the demo script; submit the title, repo URL and video on BuilderBase before 23:59.

**Prompt**

```text
Ticket T38: the submission README, checked against the code.
Follow the Shucamoxa ticket workflow in CLAUDE.md. Branch: docs/t38-readme-and-submission.

Inputs: .scratch/shucamoxa/spec.md (pitch, success criteria, threat model, known limits, roadmap),
docs/demo-evidence.md (real tx hashes from T37's runner), docs/agent-api.md, every service README, and the
architecture diagram (export docs/architecture.png from architecture-and-security.drawio if it isn't in
the repo; ask me for the file).

1. Write README.md with these sections in order: pitch line; the problem; how it works (diagram, the three
   enforcement layers, trust zones); demo scenarios 1-6 as a table with the real explorer links; Ripple's
   MVP requirements -> where each is proven (test file or tx link); threat model and known limits; how to
   run (Node 22, pnpm install, setup-treasury, db:migrate, db:seed, dev:all, pnpm test, pnpm test:policy);
   security practices; roadmap (lending, yield, FX routing, Escrow, x402, scheduled payments); team.
2. For every factual claim, find the code or test that backs it and list the claim -> file mapping in the
   PR body. Move anything unbacked to the roadmap or delete it.
3. Run every non-testnet command in the README from a clean clone in a temp directory and fix the README
   (not the code) where a command is wrong. Don't run setup-treasury or run-demo.
4. Run gitleaks detect --redact over the full history and paste the summary in the PR.
5. End by listing the human steps: make the repo public, record using the spec's recording checklist,
   submit on BuilderBase before 23:59 SAST.
Commit subject: docs: submission README backed by code and testnet evidence (T38)
```

## Comments
