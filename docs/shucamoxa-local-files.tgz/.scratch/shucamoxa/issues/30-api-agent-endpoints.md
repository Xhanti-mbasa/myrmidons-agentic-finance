# T30 · Agent-scoped read and propose endpoints

Status: ready-for-agent
Blocked by: 28, 29
Branch: feat/t30-api-agent-endpoints
Owner: W4
Priority: P0
Due: Fri 10:00

**Branch** `feat/t30-api-agent-endpoints` · **Owner** W4 · **P0** · **Depends on** T28, T29 · **Due** Fri 10:00

**Why:** this is the agent's whole world, five routes in total. The key test enumerates every route the app has and proves the agent token gets 403 on all the others, so a route added later can't quietly open up.

**Acceptance criteria**

- [ ] `services/api` is a Hono app on `127.0.0.1:8787`. The agent token is checked against `AGENT_TOKEN_SHA256` (a hash in env, never the token itself) in constant time.
- [ ] The agent scope allows exactly `GET /rules`, `GET /suppliers`, `GET /log`, `POST /approvals` and `POST /payments`. Everything else gets 403 for the agent token and 401 with no token.
- [ ] `GET /rules` and `GET /suppliers?q=` responses parse with shared schemas and contain no address anywhere (a JSON scan for r-addresses and X-addresses). `GET /suppliers` returns a confidence score using the same normalised token overlap as T15.
- [ ] `GET /log` validates `LogFilter`, returns at most 50 entries, newest first.
- [ ] `POST /approvals` parses `ApprovalRequest`, returns the existing pending approval for the same `invoiceNumber` and kind, is limited to 10 per minute, and logs `approval_requested`.
- [ ] `POST /payments` forwards to the payment service with `PAYMENT_CALLER_TOKEN`, with a 35 s timeout. Errors map to 502 or 503, never with the payment service's own error text.
- [ ] T15's `agentApiContract` suite runs against this API and passes.

**Tests:** the route-table test (iterate `app.routes`; for each method and path outside the five, the agent token gets 403); the contract suite; no address appears in any agent-scope response, even when a supplier row has a destination tag; approval dedupe and rate limit; a `GET /log` limit of 51 is clamped or rejected; a payment-service timeout gives 503; tokens are never logged.

**Prompt**

```text
Ticket T30: the agent-scoped API - five routes, and proof that the agent token reaches nothing else.
Follow the Shucamoxa ticket workflow in CLAUDE.md. Branch: feat/t30-api-agent-endpoints.

Read .scratch/shucamoxa/spec.md "Tool contracts" and "Database permissions". Routing decision: the agent
calls only this API; POST /payments is forwarded to the payment service with PAYMENT_CALLER_TOKEN.

Tests first in services/api/test/:
1. agent-scope.test.ts: iterate every registered route (app.routes, plus a list of owner routes as they
   land). With the agent token: the five allowed routes are not 401/403; every other method+path is 403.
   With no token: everything except /health is 401. This test must fail if someone adds a route without
   a scope.
2. contract.test.ts: run agentApiContract (from T15) against createApiServer with a seeded temp DB.
3. No address: seed a supplier with a destination tag; scan every agent-scope response body for
   /\br[1-9A-HJ-NP-Za-km-z]{24,34}\b/ and X-addresses -> none.
4. POST /approvals: same invoice + kind twice -> the same approvalId; the 11th in a minute -> 429;
   approval_requested logged once per new approval.
5. GET /log?limit=51 -> 400 or clamped to 50 (choose one and document it); filters validated.
6. POST /payments: forwarded with PAYMENT_CALLER_TOKEN (assert the header on a fake payment service);
   a hang beyond 35 s (injected 20 ms) -> 503 with a generic message.
7. Captured logs never contain the agent token or the payment caller token.

Implement services/api with Hono: a scope middleware where every route declares its scope (agent | owner |
public) and routes without one fail at startup; constant-time comparison of sha256(token) with
AGENT_TOKEN_SHA256; the read repos from T28; confidence scoring shared with T15 (move it into
@shucamoxa/shared if it isn't already).
Commit subject: feat(api): agent-scoped read/propose/pay endpoints with route-scope enforcement (T30)
```

## Comments

## Notes from the T15 review (2026-11-13)
- The mock replays *blocked* results: an invoice blocked under KILL_SWITCH_ON stays blocked after the switch is turned off. Policy check 9 only refuses a settled or reserved invoice. Decide in the spec which is right, assert it in `agentApiContract`, then align the mock and W4.
- The mock never returns `pending_approval`, and `reserved` is always "0.00". Cover the agent's pending_approval branch against the real API.
- Run `agentApiContract` against a throwaway W4 instance only: it creates pending approvals and sends rule-loosening bodies to owner routes.
- Still open from T15: 403 vs 404 on routes the wrong token can't use; approval de-duplication; `POST /approvals` returning 201 vs 200.
