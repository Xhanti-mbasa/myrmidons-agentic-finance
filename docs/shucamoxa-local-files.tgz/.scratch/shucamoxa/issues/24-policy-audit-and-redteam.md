# T24 · Policy audit logging and red-team replay

Status: ready-for-agent
Blocked by: 23, 16
Branch: test/t24-policy-audit-and-redteam
Owner: W2
Priority: P0
Due: Fri 15:00

**Branch** `test/t24-policy-audit-and-redteam` · **Owner** W2 · **P0** · **Depends on** T23, T16 · **Due** Fri 15:00

**Why:** the recording checklist shows the policy tests green on screen, and the spec requires every decision, including blocks, in the audit log.

**Acceptance criteria**

- [ ] Every `/cosign` decision writes one audit entry (actor `policy`, event `policy_allowed` or `policy_blocked`, rule code, invoice number, and the fixed explanation from `ruleExplanation`) through T29's log writer.
- [ ] If the log write fails, the decision becomes block and no signature is returned.
- [ ] A replay suite runs every case in `fixtures/red-team/README.md` (01 to 14) plus every threat-model row that reaches the policy layer, through the full cosign path, asserting the expected rule code.
- [ ] `pnpm test:policy` runs only the policy suite, for the recording.
- [ ] `services/policy/README.md` gets a table of check, rule code and test name.

**Tests:** each decision writes exactly one entry; a failing log writer leads to a block with no blob; the replay suite is green.

**Prompt**

```text
Ticket T24: write every policy decision to the audit log, and replay the red-team pack through the full
cosign path.
Follow the Shucamoxa ticket workflow in CLAUDE.md. Branch: test/t24-policy-audit-and-redteam.

Tests first:
1. services/policy/test/audit.test.ts: an allow writes one entry {actor: "policy", event:
   "policy_allowed", ruleCode: "OK"}; a block writes one {event: "policy_blocked", ruleCode: <code>,
   explanation: ruleExplanation(code)}; a log writer that throws turns an otherwise-valid request into a
   block with no policySignedBlob.
2. services/policy/test/redteam-replay.test.ts: for each case in fixtures/red-team/README.md and each
   threat-model row reaching the policy (unknown payee, changed address, duplicate, split payments
   (fixture 14: four allows then OVER_BUDGET), parallel overspend, partial payment, wrong asset, fake
   RLUSD, replay of an old blob (STALE_TX), fee drain), build the transaction the payment service would,
   sign it as the agent, POST /cosign, and assert the rule code.

Implement: call T29's log writer after the pipeline decides and before signing; sign only if the write
succeeded. Add a root script "test:policy" (vitest run --project services/policy). Write
services/policy/README.md with a table of check # -> rule code -> test name, and how to run.
Commit subject: test(policy): audit every decision and replay the red-team pack (T24)
```

## Comments
