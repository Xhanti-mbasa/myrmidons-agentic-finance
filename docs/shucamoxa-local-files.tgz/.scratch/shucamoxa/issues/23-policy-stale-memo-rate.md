# T23 · Stale transaction, memo match and rate limit

Status: ready-for-agent
Blocked by: 22, 29
Branch: feat/t23-policy-stale-memo-rate
Owner: W2
Priority: P0
Due: Fri 13:00

**Branch** `feat/t23-policy-stale-memo-rate` · **Owner** W2 · **P0** · **Depends on** T22, T29 · **Due** Fri 13:00

**Why:** these three close replay and log forgery: an old signed blob can't be resubmitted, and every payment must point at a real pending log entry for exactly this payment.

**Acceptance criteria**

- [ ] Check 10: `current < LastLedgerSequence <= current + LAST_LEDGER_WINDOW`, with the current ledger index from an injectable `LedgerClock` (xrpl `ledger_current` in production). If the ledger can't be reached, the request is blocked with `STALE_TX`.
- [ ] Check 11: `MemoData` equals `request.logEntryHash`, and that hash belongs to a `payment_requested` log entry whose invoice number, supplier and amount match this transaction and which hasn't been used by an earlier allow.
- [ ] Check 12: fewer than `RATE_LIMIT.count` cosign requests (allowed or blocked) in the last `RATE_LIMIT.windowMs`, counted in a sliding window with an injectable clock. A restart resets the window, so say so in the README.
- [ ] The log lookup goes through a read-only interface (W4's internal endpoint or the policy service's read role), never the agent's endpoints.

**Tests:** `LastLedgerSequence` equal to current, current + 21, or missing gives `STALE_TX`, while current + 20 passes; the ledger being unreachable gives `STALE_TX`; a memo hash with no log entry, an entry for a different invoice or amount, and a hash already used by an earlier allow each give `MEMO_MISMATCH`; a sixth request in 60 s gives `RATE_LIMITED` and the window slides with the clock; `blocks_after_kill_switch` (allowed, then kill switch on, then the same kind of request is blocked).

**Prompt**

```text
Ticket T23: policy checks 10 (stale tx), 11 (memo matches a pending log entry) and 12 (rate limit).
Follow the Shucamoxa ticket workflow in CLAUDE.md. Branch: feat/t23-policy-stale-memo-rate.

Tests first in services/policy/test/stale-memo-rate.test.ts with an injected LedgerClock, a fake
LogReader and an injected clock:
1. STALE_TX: LastLedgerSequence == current; == current + 21; missing; LedgerClock throws. Pass:
   current + 20.
2. MEMO_MISMATCH: MemoData hash not found; found but for another invoiceNumber; another supplier;
   another amount; already consumed by an earlier allow; event is not payment_requested.
3. RATE_LIMITED: five requests in 60 s pass the limiter, the sixth is blocked; after the clock moves
   61 s, a request passes. Blocked requests count too.
4. blocks_after_kill_switch: one allow, flip killSwitch, the next request -> KILL_SWITCH_ON.
5. Precedence stays the spec's order: a tx that is both stale and over budget reports OVER_BUDGET.

Implement in src/checks.ts and src/ledger-clock.ts (xrpl Client request ledger_current, a 5 s timeout,
failure -> treat as stale). LogReader is an interface; implement it against T29's log table with the
policy service's read-only role, plus a consumed-hash record written in the same transaction as the
reservation so a hash can only authorise one payment. Rate limiter: in-memory sliding window keyed on the
treasury account. Note in services/policy/README.md that a restart resets it.
Commit subject: feat(policy): stale-tx, memo-to-log and rate-limit checks (T23)
```

## Comments
