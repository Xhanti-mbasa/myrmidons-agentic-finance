# T31 · Owner auth, rules, suppliers, kill switch, approvals and relays

Status: ready-for-agent
Blocked by: 30
Branch: feat/t31-api-owner-endpoints
Owner: W4
Priority: P0
Due: Fri 12:00

**Branch** `feat/t31-api-owner-endpoints` · **Owner** W4 · **P0** · **Depends on** T30 · **Due** Fri 12:00

**Why:** "a human sets limits outside the agent" is one of Ripple's four bars. These are the only routes that change the mandate, so they need real authentication and logging.

**Acceptance criteria**

- [ ] **Login:** `POST /owner/login` checks a password against `OWNER_PASSWORD_HASH` (scrypt or argon2), limited to 5 per minute. On success it sets a session cookie that is `HttpOnly`, `SameSite=Strict`, `Secure` when served over HTTPS, and expires after 8 hours. State-changing owner routes also require an `Origin` header matching `WEB_ORIGIN`. `OWNER_API_TOKEN` (stored as a SHA-256 hash) gives scripts (T27) the owner scope.
- [ ] **Rules:** `PUT /owner/rules` validates cap, budget and period and logs `rules_changed` with before and after.
- [ ] **Suppliers:** create, update and remove. A changed address or tag sets the supplier back to `pending` until approved again with `POST /owner/suppliers/:id/approve`. Every change is logged.
- [ ] **Kill switch:** `POST /owner/kill-switch {on}`. `on: true` takes effect at once and logs `kill_switch_on`. `on: false` requires `{confirm: "RESUME"}` and logs `kill_switch_off`.
- [ ] **Approvals:** list them, and decide with `POST /owner/approvals/:id/decide`. Approving a supplier proposal requires the owner to type the last 6 characters of the proposed address, so a swapped address is visible. Payment approvals hand off to T32. Decisions log `approval_decided`.
- [ ] **Signer list:** `POST /owner/signer-list {action, txHash}` fetches the transaction from testnet, confirms it's a validated `SignerListSet` on the treasury, then logs `signer_list_changed`.
- [ ] **Relays:** `POST /owner/invoices` (text or PDF up to 2 MB) forwards to the agent's `POST /agent/invoices` with `AGENT_INBOUND_TOKEN`, then logs `invoice_received` and `invoice_extracted` with the `AgentExplanation`. `POST /owner/chat` streams the agent's SSE through unchanged.
- [ ] Every owner route is added to the T30 route-table test, which proves the agent token gets 403 on all of them.

**Tests:** login success and failure, rate limit, cookie flags, expiry; a missing or foreign `Origin` gets 403 on every state-changing owner route; a supplier address change sets it to `pending` and pay is then blocked; approving a supplier with the wrong last-6 confirmation is refused; kill switch off without confirmation is refused; a fake signer-list hash is refused; the invoice relay logs both events and returns the outcome; the agent token gets 403 everywhere here.

**Prompt**

```text
Ticket T31: owner-only API - login, rules, suppliers, kill switch, approvals, signer-list record, and the
invoice/chat relays to the agent.
Follow the Shucamoxa ticket workflow in CLAUDE.md. Branch: feat/t31-api-owner-endpoints.

Read .scratch/shucamoxa/spec.md "Data model", "Kill switch", "Events logged" and the demo script. If the
squad chose Supabase Auth (decision D2), use it and keep every test below; otherwise do the single-owner
login described here.

Tests first in services/api/test/owner/*.test.ts:
1. Login: correct password -> Set-Cookie with HttpOnly, SameSite=Strict, Max-Age 28800 (and Secure when
   WEB_ORIGIN is https); wrong password -> 401; the 6th attempt in a minute -> 429; an expired session ->
   401.
2. CSRF: every POST/PUT/PATCH/DELETE under /owner with a missing or foreign Origin -> 403.
3. PUT /owner/rules -> rules_changed logged with before/after; cap 0 or negative -> 400.
4. Changing a supplier's address -> status pending; a subsequent POST /payments for that supplier is
   blocked SUPPLIER_NOT_APPROVED; POST /owner/suppliers/:id/approve restores it; each step logged.
5. Approving a supplier proposal with the wrong last-6 confirmation -> 400; with the right one -> the
   supplier is created approved with exactly the proposed address.
6. Kill switch: {on: true} -> immediate, the next GET /rules shows killSwitch true; {on: false} without
   {confirm: "RESUME"} -> 400.
7. POST /owner/signer-list with a hash the injected XRPL client says isn't a validated SignerListSet on
   the treasury -> 400; a valid one -> signer_list_changed logged with the hash.
8. POST /owner/invoices relays to a fake agent with AGENT_INBOUND_TOKEN, logs invoice_received and
   invoice_extracted (explanation parsed as AgentExplanation), and returns the outcome. POST /owner/chat
   streams the fake agent's SSE through byte for byte.
9. Add every /owner route to the T30 agent-scope test: the agent token -> 403 on all of them.

Implement in services/api with the scope middleware from T30 (scope "owner"), scrypt from node:crypto for
the password hash (add pnpm owner:hash-password to generate OWNER_PASSWORD_HASH), an in-memory session
store with random 32-byte IDs, Origin checks against WEB_ORIGIN, and the T28 write repos.
Commit subject: feat(api): authenticated owner endpoints, audit-logged, with agent relays (T31)
```

## Comments
