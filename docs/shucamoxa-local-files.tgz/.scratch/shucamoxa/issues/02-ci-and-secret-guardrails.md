# T02 · CI, typecheck and secret scanning

Status: resolved
Blocked by: 01
Branch: ci/t02-ci-and-secret-guardrails
Owner: Cam
Priority: P0
Due: Thu 23:30

**Branch** `ci/t02-ci-and-secret-guardrails` · **Owner** Cam · **P0** · **Depends on** T01 · **Due** Thu 23:30

**Why:** six people and several AI coding tools will push to one repo in 20 hours. Ripple warned about seeds in public repos, and the threat model lists "AI coding tool writes .env to repo".

**Acceptance criteria**

- [ ] `.github/workflows/ci.yml` runs on pull requests and on pushes to `main`. Steps: checkout, pnpm setup, Node 22, `pnpm install --frozen-lockfile`, `pnpm typecheck`, `pnpm test`. It sets `permissions: contents: read` and pins every third-party action to a full commit SHA.
- [ ] A second job runs gitleaks over the full history (`fetch-depth: 0`) with the gitleaks CLI or official container, not `gitleaks-action` (which needs a licence for organisations).
- [ ] `.gitleaks.toml` extends the default rules with an XRPL family-seed rule (base58 starting with `s`, 29 to 31 characters) and a 64-hex private-key rule. The allowlist covers only `services/agent/test/config.test.ts` and other named test files that hold deliberately fake seeds.
- [ ] A CI step fails if any tracked path matches `.env` (except `.env.example`), `CLAUDE.md`, `.scratch/` or `docs/agents/`.
- [ ] A pre-commit hook in `.githooks/pre-commit` runs `gitleaks protect --staged --redact` when gitleaks is installed, and warns (not fails) when it isn't. A `prepare` script sets `git config core.hooksPath .githooks`.
- [ ] The README explains how to install gitleaks and what the hook does.

**Tests:** prove the scanner works. On a scratch branch that is never pushed, commit a file holding a fake `sEd…` seed and confirm both the hook and `gitleaks detect` fail. Then delete the branch.

**Human step (ready-for-human):** the repo owner turns on branch protection for `main` so the CI job is required. Claude Code can't do this without admin rights.

**Prompt**

```text
Ticket T02: CI, typecheck and secret scanning for the shared repo.
Follow the Shucamoxa ticket workflow in CLAUDE.md. Branch: ci/t02-ci-and-secret-guardrails.

1. Add .github/workflows/ci.yml, triggered on pull_request and on push to main. Job "test":
   checkout, pnpm/action-setup, actions/setup-node (Node 22, pnpm cache), pnpm install
   --frozen-lockfile, pnpm typecheck, pnpm test. Set permissions: contents: read. Pin every
   action to a full commit SHA, with the version in a trailing comment.
2. Job "secrets": checkout with fetch-depth: 0, then run gitleaks detect --redact --no-banner
   over the whole history using the official gitleaks container image or release binary.
   Don't use gitleaks/gitleaks-action.
3. Add .gitleaks.toml that extends the default config and adds:
   - an XRPL family-seed rule: s followed by 28-30 characters from the Ripple base58 alphabet
     (rpshnaf39wBUDNEGHJKLM4PQRST7VWXYZ2bcdeCg65jkm8oFqi1tuvAxyz)
   - a rule for 64-hex private keys, optionally prefixed with ED or 00
   - an allowlist limited to the exact test files that hold deliberately fake seeds
     (services/agent/test/config.test.ts today). No directory-wide allowlists.
4. In the "test" job, add a step that fails if git ls-files shows any .env file other than
   .env.example, or any of CLAUDE.md, CLAUDE.local.md, .scratch/, docs/agents/, CONTEXT.md, docs/adr/.
5. Add .githooks/pre-commit (POSIX sh, executable): if gitleaks is on PATH, run
   gitleaks protect --staged --redact --no-banner and fail on findings; otherwise print a one-line
   warning and continue. Add "prepare": "git config core.hooksPath .githooks || true" to the root
   package.json.
6. Update README.md: install gitleaks, what CI checks, what the hook does.
7. Prove it: on a throwaway local branch you never push, commit a file with a fake seed
   (sEdTFAKEFAKEFAKEFAKEFAKEFAKEFAK, 31 characters) and show that the hook and gitleaks detect both fail. Then delete
   that branch and confirm it was never pushed. Put the evidence in the PR body.

Finish per the workflow. After merging, tell me to ask the repo owner to require the "test" and
"secrets" checks on main in branch protection.
Commit subject: ci: add CI, typecheck and gitleaks secret scanning (T02)
```

## Comments
- 2026-11-13 00:05 SAST: merged as PR #3 after independent review (2 should-fix fixed). First CI run green.
