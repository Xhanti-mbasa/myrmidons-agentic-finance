# T29 · Hash-chained, append-only audit log

Status: ready-for-agent
Blocked by: 28
Branch: feat/t29-audit-log-hash-chain
Owner: W4
Priority: P0
Due: Fri 10:00

**Branch** `feat/t29-audit-log-hash-chain` · **Owner** W4 · **P0** · **Depends on** T28 · **Due** Fri 10:00

**Why:** the log is on the never-cut list, and each payment memo carries an entry hash so the ledger proves the log. The chain must not fork when the API, policy and payment processes all append at once.

**Acceptance criteria**

- [ ] `appendLog(entry)` in `packages/db`: inside `BEGIN IMMEDIATE`, it reads the last `seq` and `hash`, computes `hashLogEntry(prevHash, rowWithoutHash)` from `@shucamoxa/shared` (the row includes `seq` and `ts`), inserts, and returns `{seq, hash}`.
- [ ] Entries are validated with `LogEntry` before writing. `explanation` is capped at 500 characters with control characters stripped.
- [ ] `verifyLog()` returns the first bad `seq` or `null`, using `verifyChain`.
- [ ] Owner-only `GET /log/verify` returns `{intact, firstBadSeq, count}`.
- [ ] The clock is injectable. `ts` is ISO UTC with milliseconds.

**Tests:** 3 child processes each append 50 entries concurrently, then the chain verifies and `seq` runs 1 to 150 with no gaps; editing a row through a raw connection with the triggers dropped is detected at that `seq`; deleting and reordering rows are detected; a genesis row with the wrong `prev_hash` is detected; the hash of a fixed entry matches the T03 known-answer value, so every service agrees.

**Prompt**

```text
Ticket T29: the hash-chained, append-only audit log writer and verifier.
Follow the Shucamoxa ticket workflow in CLAUDE.md. Branch: feat/t29-audit-log-hash-chain.

Read .scratch/shucamoxa/spec.md "Hash chain" and "Events logged". Use canonicalJson, hashLogEntry,
verifyChain and GENESIS_HASH from @shucamoxa/shared; don't reimplement hashing.

Tests first in packages/db/test/log.test.ts:
1. Concurrency: spawn 3 child processes (node:child_process fork) that each append 50 entries to the same
   temp DB file at once -> verifyLog() is null and seq is exactly 1..150.
2. Tamper detection (drop the triggers on a raw connection in the test only): edit row 40's amount ->
   verifyLog() returns 40; delete row 10 -> detected; swap two rows' contents -> detected; first row's
   prev_hash not GENESIS_HASH -> 1.
3. Known answer: appending the T03 known-answer entry as the first row yields the T03 expected hash.
4. Validation: an entry with an unknown event, a float amount, or an explanation over 500 chars -> rejected
   or truncated as specified, never written invalid.
5. GET /log/verify (owner session only) returns {intact: true, count} and 403 for the agent token.

Implement appendLog and verifyLog in packages/db/src/log.ts: BEGIN IMMEDIATE, read the last row, compute
the hash over the row including seq and ts (injectable clock), insert, commit, return {seq, hash}. Add GET
/log/verify to services/api behind the owner guard (stub the guard if T31 isn't merged; leave a TODO that
T31 removes).
Commit subject: feat(log): concurrent-safe hash-chained audit log with verification (T29)
```

## Comments
