# T04 · Bind pay to the invoice's own supplier (G1, G9)

Status: resolved
Blocked by: 03
Branch: fix/t04-agent-bind-supplier
Owner: Cam
Priority: P0
Due: Fri 00:30

**Branch** `fix/t04-agent-bind-supplier` · **Owner** Cam · **P0** · **Depends on** T03 · **Due** Fri 00:30

**Why:** today a hostile planner can pay any approved supplier for any invoice, and neither the policy service nor the ledger can tell. The fix moves supplier resolution out of the model: code looks up the invoice's own supplier before the planner runs, and `pay` accepts only that ID.

**Acceptance criteria**

- [ ] In `processInvoice`, after the kill-switch check, code calls `backend.findSupplier(invoice.supplierName)` itself and parses the reply with `SupplierLookup`.
- [ ] A match with `confidence >= 0.85` (a constant `MIN_SUPPLIER_CONFIDENCE`) becomes `mandate.supplierId`. Below that, or `notFound`, the mandate gets no supplier and `pay` refuses everything.
- [ ] `refusePay` also refuses when `request.supplierId !== mandate.supplierId`, with a reason the model can read.
- [ ] The planner still has `find_supplier`, but in invoice mode its results never add to the set of payable IDs. They only inform `propose_supplier`.
- [ ] Chat mode keeps `knownSupplierIds`, but only for matches at or above the confidence threshold.
- [ ] The planner's first message names the resolved supplier ID, or says none matched, so a good model doesn't waste steps.

**Tests** (add to `agent-run.test.ts`; each asserts on `backend.payments`)

- Karoo invoice, model looks up Zambezi and pays `sup_zambezi`: no payment.
- Backend returns confidence 0.1 for Karoo: no payment, and the outcome is `awaiting_owner` (if the model proposes) or `needs_review`.
- Confidence exactly 0.85: pays.
- Happy path still pays exactly once, with the code-resolved ID.
- Chat: a low-confidence match can't be paid.

**Prompt**

```text
Ticket T04: bind pay() to the invoice's own supplier, resolved by code, not by the model.
Follow the Shucamoxa ticket workflow in CLAUDE.md. Branch: fix/t04-agent-bind-supplier.

The gaps (both reproduced):
- G1: in services/agent, the planner can call find_supplier("Zambezi Spices") and then
  pay({supplierId: "sup_zambezi", amount: "30.00", invoiceNumber: "INV-1042"}) for Karoo's invoice.
  refusePay in src/tools.ts checks invoice number and amount but not the supplier, and the policy
  service can't catch it because Zambezi is approved and the address is Zambezi's own.
- G9: any supplierId find_supplier returns is payable, even with confidence 0.1.

Write these failing tests first in services/agent/test/agent-run.test.ts, asserting on
backend.payments (never on model text):
1. Karoo invoice; planner calls find_supplier("Zambezi Spices") then pays sup_zambezi 30.00 INV-1042
   -> zero payments.
2. GET /suppliers answers {supplierId: "sup_karoo", name: "Karoo Textiles", confidence: 0.1}
   -> zero payments; decision is not "paid".
3. Confidence exactly 0.85 -> one payment.
4. The existing happy path still pays exactly once.
5. chat(): a match with confidence 0.5 cannot be paid.
You'll need a fakeBackend option to set the confidence; add it without changing existing defaults.

Then implement:
- In src/agent.ts processInvoice, after the kill-switch check, call backend.findSupplier(
  invoice.supplierName) in code, parse with SupplierLookup from @shucamoxa/shared, and set
  mandate.supplierId only when confidence >= MIN_SUPPLIER_CONFIDENCE (0.85, exported constant).
- Extend RunState.mandate with supplierId: string | null. In refusePay, when a mandate exists, refuse
  unless request.supplierId === mandate.supplierId (null refuses everything) with the reason
  "This invoice can only be paid to its own supplier, matched by the system. Use propose_supplier if it
  is new."
- In invoice mode, find_supplier results must not add to knownSupplierIds. In chat mode, add only
  matches at or above the threshold.
- Tell the planner the result up front: include {resolvedSupplierId} or {resolvedSupplierId: null}
  alongside the invoice fields in its prompt. Supplier IDs aren't secret, but never include an address.

Run the break-it check on each new guard. Keep the existing tests unchanged.
Commit subject: fix(agent): pay only the invoice's own supplier, matched by code (T04)
```

## Comments
