# T22 · Atomic budget reservation and duplicate check

Status: ready-for-agent
Blocked by: 21, 28
Branch: feat/t22-policy-budget-reservation
Owner: W2
Priority: P0
Due: Fri 12:00

**Branch** `feat/t22-policy-budget-reservation` · **Owner** W2 · **P0** · **Depends on** T21, T28 · **Due** Fri 12:00

**Why:** this is the parallel-overspend and duplicate-invoice defence. It's only real if it's tested with genuine concurrency against the real database, not a mock.

**Acceptance criteria**

- [ ] Checks 8 and 9 run inside one database transaction that reads spent plus reserved for the current budget period and inserts a `reserved` row. In SQLite use `BEGIN IMMEDIATE`; in Postgres use `SERIALIZABLE` with a retry or a row lock on the rules row.
- [ ] A partial unique index on `invoice_number WHERE status IN ('reserved','settled')` makes the database itself refuse a duplicate. A `released` invoice may be tried again.
- [ ] If a later check (10 to 12) fails, the transaction rolls back and nothing stays reserved. The reported rule code still follows the spec's order.
- [ ] `POST /reservations/:invoiceNumber/settle {txHash}` and `/release` are callable only with the payment service's token. A sweeper releases `reserved` rows older than `RESERVATION_TTL_MS`, and the clock is injectable.
- [ ] Budget totals are summed as integer cents, never with SQL floats (store amounts as integer cents or decimal text and sum in code).

**Tests:** `blocks_parallel_overspend` (20 concurrent `POST /cosign` calls of $45 each against a real database file give at most 4 allows); `blocks_duplicate_invoice` (sequential and concurrent); after a release the same invoice can be allowed again; the TTL sweeper releases with a fake clock; check 10 failing after 8 and 9 pass leaves no reservation; settle and release refuse the agent's token.

**Prompt**

```text
Ticket T22: policy checks 8 (budget) and 9 (duplicate) with an atomic reservation.
Follow the Shucamoxa ticket workflow in CLAUDE.md. Branch: feat/t22-policy-budget-reservation.

Read .scratch/shucamoxa/spec.md "Budget reservation" and the reservations table in "Data model". T28 set up
the database; use its migrations and the policy service's own DB role/credentials (never the agent's).

Tests first in services/policy/test/reservation.test.ts against a REAL database (a temp SQLite file, or
the local Postgres from T28 if that's what the squad chose). No mocks for the concurrency tests:
1. blocks_parallel_overspend: budget 200.00, spent 0, 20 concurrent cosign requests of 45.00 with distinct
   invoice numbers -> exactly 4 allows and 16 OVER_BUDGET; sum of reserved = 180.00.
2. blocks_duplicate_invoice: same invoice twice sequentially -> second is DUPLICATE_INVOICE; 10
   concurrent requests for one invoice -> exactly one allow.
3. Release then retry the same invoice -> allowed.
4. The sweeper with an injected clock releases a reservation older than RESERVATION_TTL_MS and leaves a
   newer one.
5. A request that passes 8 and 9 but fails a later check (inject a failing check 10 for this test) leaves
   no reserved row.
6. POST /reservations/:inv/settle and /release: 401 for the agent's token and no token; 200 for the
   payment service's token; settle requires a 64-hex txHash.
7. Budget arithmetic in cents: 0.10 + 0.20 reserved equals 0.30 exactly.

Implement src/reservations.ts. Do checks 8 and 9 in one transaction (SQLite: BEGIN IMMEDIATE; Postgres:
SERIALIZABLE with up to 3 retries on serialization failure), add the partial unique index in a T28-style
migration if it's missing, and sum amounts in code as bigint cents. Expose settle/release on the policy
service with constant-time bearer auth using POLICY_CALLER_TOKEN. Start the sweeper in main.ts with a
15 s interval.
Commit subject: feat(policy): atomic budget reservation and duplicate-invoice check (T22)
```

## Comments
