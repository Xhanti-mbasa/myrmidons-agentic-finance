# T11 · Kill the surviving mutants; make TESTING.md accurate

Status: ready-for-agent
Blocked by: 04, 05, 06, 07, 08, 09, 10
Branch: test/t11-agent-mutation-hardening
Owner: Cam
Priority: P1
Due: Fri 11:00

**Branch** `test/t11-agent-mutation-hardening` · **Owner** Cam · **P1** · **Depends on** T04 to T10 · **Due** Fri 11:00

**Why:** five of six mutations survived, and judges may ask how you know the guards work. After this ticket the claim in TESTING.md should be true and repeatable.

**Acceptance criteria**

- [ ] New tests kill: regex address redaction disabled (leak an address under an unknown key such as `wallet`, and inside a free-text string); temperature not 0 (assert `temperature: 0` in both stages' model calls); extraction `maxRetries` not 1 (a failing model is called exactly twice).
- [ ] Redaction also covers `xrpl_address` (snake case, as in the DB schema), `account`, `payTo` and `wallet` keys, plus X-addresses (`X…` or `T…`, 47 characters).
- [ ] A kill switch turned on mid-run (rules said off, then `POST /payments` returns `KILL_SWITCH_ON`) gives `blocked` with `KILL_SWITCH_ON`.
- [ ] Amount equivalence: mandate `30.00` accepts `pay.amount` `30` and `30.0`, and refuses `30.01`.
- [ ] Stryker is set up for `services/agent/src/{tools,config,extraction,grounding,normalise}.ts` as `pnpm mutate` (not in CI because it's slow), with a break threshold of 80%. Paste the score in the PR.
- [ ] TESTING.md lists each guard, the test that proves it, and the date of the last mutation run.

**Prompt**

```text
Ticket T11: kill the surviving mutants and make TESTING.md's claims true.
Follow the Shucamoxa ticket workflow in CLAUDE.md. Branch: test/t11-agent-mutation-hardening.

A manual mutation run found these survived (no test failed):
- redactAddresses' string branch disabled (only key-based stripping left)
- the <invoice> tag regex made case-sensitive (T06 should have covered this; confirm)
- temperature 0 -> 1 in both stages
- extraction maxRetries 1 -> 5

1. Re-run each of those mutations on current main and record which still survive.
2. Add tests that kill them: leak an address under key "wallet" and inside a sentence in a tool result;
   assert temperature: 0 in plannerModel.calls[i] and extractionModel.calls[0]; a failing extraction
   model is called exactly 2 times.
3. Extend redaction: keys xrpl_address, account, payTo, wallet (case-insensitive key match) and
   X-addresses (/\b[XT][1-9A-HJ-NP-Za-km-z]{46}\b/). Tests first.
4. Add a test: GET /rules says killSwitch false, POST /payments returns blocked KILL_SWITCH_ON ->
   outcome blocked, ruleCode KILL_SWITCH_ON, explanation from ruleExplanation.
5. Add tests: mandate "30.00" accepts "30" and "30.0", and refuses "30.01".
6. Add Stryker (@stryker-mutator/core and the vitest runner) as a dev dependency of services/agent with a
   config limited to src/tools.ts, src/config.ts, src/extraction.ts, src/grounding.ts and
   src/normalise.ts, and a root script "mutate". thresholds.break = 80. Don't add it to CI. Run it once and
   kill any survivors that represent a real guard; list the rest as equivalent mutants in the PR.
7. Rewrite services/agent/TESTING.md: a table of guard -> test file and test name -> what breaking it
   proves, the Stryker score and the date. Remove any claim that isn't backed by a test.
Commit subject: test(agent): kill surviving mutants, add Stryker, make TESTING.md accurate (T11)
```

## Comments
