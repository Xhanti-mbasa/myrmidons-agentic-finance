# T19 · Contingency: merge the two approval tools

Status: ready-for-agent
Blocked by: 18
Branch: feat/t19-merged-approval-tool
Owner: Cam
Priority: P2
Due: Fri 12:00

**Branch** `feat/t19-merged-approval-tool` · **Owner** Cam · **P2** · **Depends on** T18 failing on tool confusion · **Due** Fri 12:00 if needed

**Why:** the spec's fallback for a weak model is fewer, simpler tools. Only do this if T18 or T17 shows the model mixing up `propose_supplier` and `request_approval`.

**Acceptance criteria**

- [ ] Behind `AGENT_TOOLSET=merged`, the planner gets `request_owner_approval({kind: "supplier"|"payment", …})` instead of the two tools. `POST /approvals` and every T05 binding rule are unchanged.
- [ ] The planner prompt gains the two worked examples from the spec (one pay, one block).
- [ ] All T05 tests run against both tool sets (parameterised).

**Prompt**

```text
Ticket T19 (only if the smoke test or eval showed tool confusion): merge propose_supplier and
request_approval into one request_owner_approval tool, behind AGENT_TOOLSET=merged.
Follow the Shucamoxa ticket workflow in CLAUDE.md. Branch: feat/t19-merged-approval-tool.

1. Parameterise the T05 tests (describe.each over ["split", "merged"]) so every binding rule is proven for
   both tool sets. Run them: the merged ones fail.
2. Implement request_owner_approval as a discriminated union on kind ("supplier" | "payment"),
   delegating to the same refusal functions and the same POST /approvals payloads as the split tools.
3. Add AGENT_TOOLSET to the T09 allowlist (values: split, merged; default split).
4. Add two short worked examples to the planner prompt in src/prompts.ts (one valid invoice -> pay, one
   unknown supplier -> approval), and update the smoke test to send the merged tool set when
   AGENT_TOOLSET=merged.
Commit subject: feat(agent): optional merged owner-approval tool for weaker models (T19)
```

## Comments
