# T03b · Rename PayGuard to Shucamoxa in the repo

Status: resolved
Blocked by: 03
Branch: chore/t03b-rename-shucamoxa
Owner: Cam
Priority: P0
Due: Fri 03:30

**Why:** Cam asked (13 Nov, 00:12) for the product name PayGuard to become Shucamoxa everywhere. Docs, tickets and the Project are already renamed. This ticket does the tracked code, so every later ticket builds on the new names.

**Acceptance criteria**

- [ ] Package names: `@payguard/shared` → `@shucamoxa/shared`, `@payguard/agent` → `@shucamoxa/agent`, plus every import, `--filter` and workspace reference. `pnpm-lock.yaml` regenerated.
- [ ] `MEMO_TYPE` becomes `"shucamoxa/log"`. Nothing is on the ledger yet, so no migration is needed.
- [ ] Prompts, the model provider name, the smoke test, README, `.env.example`, gitleaks rule descriptions, hooks and test fixtures say Shucamoxa. Use `SHUCAMOXA_` for any env-var prefix.
- [ ] `git grep -i payguard` on the branch returns nothing, except real external file names (none expected in the repo).
- [ ] No behaviour change beyond the renamed strings. Typecheck, tests, seedscan and the tracked-paths check all pass.

**Out of scope:** merged commit messages and PR titles on `main` (history isn't rewritten), the repo name, and teammates' branches.
