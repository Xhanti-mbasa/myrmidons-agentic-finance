# T14 · PDF text extraction and CLI invoice loader

Status: ready-for-agent
Blocked by: 12
Branch: feat/t14-agent-pdf-and-cli
Owner: Cam
Priority: P1
Due: Fri 12:30

**Branch** `feat/t14-agent-pdf-and-cli` · **Owner** Cam · **P1** · **Depends on** T12 · **Due** Fri 12:30

**Why:** local models often can't read PDFs, so the agent sends text (spec: unpdf). The CLI is the fallback trigger if the dashboard upload isn't ready.

**Acceptance criteria**

- [ ] `POST /agent/invoices` also accepts `{invoiceId, pdfBase64}` (exactly one of `text` or `pdfBase64`).
- [ ] PDF limits: 2 MB decoded, must start with `%PDF-`, at most 5 pages, extraction times out after 10 s. Encrypted or unreadable PDFs and PDFs with no text go to `needs_review`. The extracted text then goes through the same path as `text`.
- [ ] CLI `pnpm agent:invoice <file.pdf|file.txt>` posts to the running agent service using `AGENT_URL` and `AGENT_INBOUND_TOKEN` and prints a one-screen summary. `pnpm agent:invoice --demo` runs fixtures 01 to 06 in order with a pause between each.
- [ ] The CLI reads its token from the environment, never from a flag, so it doesn't land in shell history.

**Tests:** a PDF generated in the test with pdf-lib extracts the Karoo text and gets paid; a non-PDF with a `.pdf` name gets 400; a 3 MB PDF gets 413 or 400; a 6-page PDF and an empty-text PDF give `needs_review`; the CLI's argument parsing and output formatting are unit-tested with the HTTP call stubbed.

**Prompt**

```text
Ticket T14: accept PDF invoices (as extracted text) and add a CLI invoice loader.
Follow the Shucamoxa ticket workflow in CLAUDE.md. Branch: feat/t14-agent-pdf-and-cli.

Tests first:
1. services/agent/test/pdf.test.ts: build a PDF in the test with pdf-lib (dev dependency) containing the
   Karoo invoice text; POST {invoiceId, pdfBase64} -> paid. Also: both text and pdfBase64 -> 400; neither
   -> 400; bytes not starting with %PDF- -> 400; over 2 MB decoded -> 413; 6 pages -> needs_review; a PDF
   with no text layer -> needs_review.
2. services/agent/test/cli.test.ts: argument parsing (file path, --demo), refusal when AGENT_INBOUND_TOKEN
   is missing, the summary formatting for each decision, with fetch stubbed.

Implement:
- src/pdf.ts using unpdf (extractText with mergePages) behind a 10 s timeout and the size, magic-byte and
  page limits. Extracted text goes through the exact same extraction path as text input (T06 normalising
  and grounding included).
- src/cli.ts plus a root script "agent:invoice". It reads AGENT_URL (default http://127.0.0.1:8790) and
  AGENT_INBOUND_TOKEN from the environment only; no token flag. --demo runs fixtures/invoices/01-06 in
  order, printing decision, rule code, tx hash (with a testnet.xrpl.org link when present) and flags, and
  waits for Enter between invoices.
Commit subject: feat(agent): PDF invoices via text extraction, and a CLI invoice loader (T14)
```

## Comments
