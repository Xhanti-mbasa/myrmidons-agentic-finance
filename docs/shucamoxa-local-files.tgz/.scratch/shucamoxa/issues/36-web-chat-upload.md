# T36 · Chat panel and invoice upload

Status: ready-for-agent
Blocked by: 13, 33
Branch: feat/t36-web-chat-upload
Owner: W5
Priority: P1
Due: Fri 16:00

**Branch** `feat/t36-web-chat-upload` · **Owner** W5 · **P1** · **Depends on** T13, T33 · **Due** Fri 16:00

**Acceptance criteria**

- [ ] **Upload:** a PDF or text file up to 2 MB (checked in the browser and again on the server) goes to `POST /api/owner/invoices`. An outcome card shows the decision, rule code, fixed explanation, flags, any untrusted-text box, and the tx link.
- [ ] **Chat:** it reads the SSE stream from `POST /api/owner/chat` with `fetch` and a stream reader, not `EventSource`, since it's a POST. Tool events appear as chips ("find\_supplier ✓", "pay ✗ OVER\_BUDGET").
- [ ] The model's text is labelled "Agent says". The deterministic `summary` appears separately and is styled as the trusted record, so a model claiming "paid" can't be mistaken for a payment.
- [ ] While the kill switch is on, the chat input shows the revoked state.

**Tests:** the SSE parser handles split chunks and multi-line data; the summary renders separately from the model text; a model text saying "Paid!" next to a summary of "No payment was made (OVER\_BUDGET)" shows both, with the summary as the record; files over 2 MB and `.exe` files are refused; the flags and untrusted-text box render.

**Prompt**

```text
Ticket T36: invoice upload and the streaming chat panel.
Follow the Shucamoxa ticket workflow in CLAUDE.md. Branch: feat/t36-web-chat-upload.

Read docs/agent-api.md (from T13) for the event shapes. The chat endpoint is POST /api/owner/chat via the
T33 proxy and T31 relay; use fetch plus a ReadableStream reader, not EventSource.

Tests first (Testing Library):
1. parseSSE handles events split across chunks, multiple events in one chunk and multi-line data.
2. Chat with events [tool find_supplier ok, tool pay ok:false ruleCode OVER_BUDGET, text "Paid!", summary
   "No payment was made (OVER_BUDGET).", done]: chips "find_supplier ✓" and "pay ✗ OVER_BUDGET"; "Paid!"
   under an "Agent says" label; the summary in a separate element with role="status" labelled "Record".
3. Upload: a 2.1 MB file and an .exe are refused before any request; a PDF posts to
   /api/owner/invoices; the outcome card shows decision, rule code, explanation, flags and the untrusted
   text box.
4. Kill switch on -> the chat input is disabled and shows "Agent payment authority revoked".

Implement the Chat page (panel + upload). Render every model and invoice string as plain text.
Commit subject: feat(web): invoice upload and streaming chat with a separate trusted summary (T36)
```

## Comments
