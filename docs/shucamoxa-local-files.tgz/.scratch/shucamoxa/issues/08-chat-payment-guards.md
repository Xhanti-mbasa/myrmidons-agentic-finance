# T08 · Chat payment guards (G6)

Status: ready-for-agent
Blocked by: 04
Branch: fix/t08-chat-payment-guards
Owner: Cam
Priority: P1
Due: Fri 09:30

**Branch** `fix/t08-chat-payment-guards` · **Owner** Cam · **P1** · **Depends on** T04 · **Due** Fri 09:30

**Why:** "Pay Johnson $30 now" is a demo feature, but in chat the model picks invoice numbers and payment counts, and its reply is unchecked text.

**Acceptance criteria**

- [ ] In chat, the `pay` tool's input has no `invoiceNumber`. Code generates `CHAT-<YYYYMMDD>-<8 random base32 chars>`, which can never collide with a supplier invoice number.
- [ ] At most one `pay` attempt per chat run. Further attempts are refused.
- [ ] Before payment, code extracts the amount from the owner's message with a regex (for example `$30`, `30.00` or `USD 30`) and refuses unless `pay.amount` equals it. If no single amount is found, `pay` is refused and the model must ask.
- [ ] The chat reply is the model's text followed by a deterministic summary built from `state.payResults` and `state.approvals` ("Paid 30.00 to sup\_karoo, tx ABC…", or "No payment was made."). `ChatAnswer` gains `summary` so the UI can show it separately.

**Tests:** the G6 probe makes at most one payment, with a `CHAT-` invoice number; the model can't supply `invoiceNumber`; "Pay Karoo $30 now" with `pay.amount` 45 means no payment; a message with two amounts means no payment; when the model's text says "paid" but the backend blocked, the summary says "No payment was made" with the rule code.

**Prompt**

```text
Ticket T08: guard payments made from owner chat.
Follow the Shucamoxa ticket workflow in CLAUDE.md. Branch: fix/t08-chat-payment-guards.

The gap (reproduced, G6): in chat mode the mandate is null, so the model chooses invoice numbers. In one
run it paid INV-1044, INV-1045 and INV-1046 (squatting real invoice numbers, which would block those
invoices later as DUPLICATE_INVOICE), then replied "I only paid once."

Failing tests first in services/agent/test/chat.test.ts, asserting on backend.payments:
1. The G6 script (three pay calls) -> at most one payment, and its invoiceNumber matches
   /^CHAT-\d{8}-[A-Z2-7]{8}$/.
2. A pay call that includes invoiceNumber -> rejected by the schema; no payment.
3. "Pay Karoo $30 now" with pay amount "45.00" -> no payment.
4. "Pay Karoo $30 or $40" -> no payment (ambiguous amount).
5. Backend blocks with OVER_BUDGET while the model says "Paid!" -> answer.summary says no payment was
   made and names OVER_BUDGET; answer.reply ends with that summary.
6. The existing chat tests still pass, updated only where the invoiceNumber is now generated.

Implement in src/agent.ts and src/tools.ts:
- A chat tool set whose pay input is {supplierId, amount, reason}. Code generates the invoiceNumber with
  crypto.getRandomValues and RFC 4648 base32.
- RunState.chatMandate: {amount} parsed from the owner's message by a small pure function
  (ownerAmountFromMessage) that accepts one amount like "$30", "30", "30.00" or "USD 30" and returns null
  for none or several. pay refuses if null or not equal in cents.
- One pay attempt per chat run.
- chat() returns {reply, summary, payments}, where summary is built only from state.payResults and
  state.approvals, and reply = model text + "\n\n" + summary.
Run the break-it check.
Commit subject: fix(agent): code-generated chat invoice numbers, one payment per chat, true summary (T08)
```

## Comments
