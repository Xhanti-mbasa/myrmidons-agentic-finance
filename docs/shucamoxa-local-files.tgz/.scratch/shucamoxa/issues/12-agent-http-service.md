# T12 · Agent HTTP service: process-invoice endpoint

Status: ready-for-agent
Blocked by: 09, 10
Branch: feat/t12-agent-http-service
Owner: Cam
Priority: P0
Due: Fri 12:00

**Branch** `feat/t12-agent-http-service` · **Owner** Cam · **P0** · **Depends on** T09, T10 · **Due** Fri 12:00

**Why:** the agent has to run as its own process with its own allowlisted environment (spec, process isolation). The backend relays uploaded invoices to it and writes the returned explanation into the audit log, so the agent never needs a log-writing endpoint.

**Acceptance criteria**

- [ ] `services/agent/src/server.ts` builds a Hono app with `createAgentServer(deps)`. `src/main.ts` loads config (T09), builds both models from `model.ts`, and listens on `AGENT_HOST` (default `127.0.0.1`) and `AGENT_PORT` (default `8790`).
- [ ] `GET /health` returns `{ok: true}` and nothing about config.
- [ ] `POST /agent/invoices` takes `{invoiceId, text}` (Zod, strict, `text` at most 20,000 characters) and returns `{outcome: AgentOutcome, explanation: AgentExplanation}`.
- [ ] Every route except `/health` requires `Authorization: Bearer <AGENT_INBOUND_TOKEN>`, compared in constant time. The agent's outbound backend token is a different value and is refused inbound.
- [ ] Request bodies over 1 MB get 413. Malformed JSON gets 400 without a stack trace.
- [ ] One invoice is processed at a time (an in-process queue). A second request for an `invoiceId` already in flight gets 409.
- [ ] Logs carry the invoice ID, decision, rule code and timings, but never invoice text, tokens or model output.
- [ ] `pnpm --filter @shucamoxa/agent start` runs it. `services/agent/.env.example` gains `AGENT_INBOUND_TOKEN`, `AGENT_HOST` and `AGENT_PORT`.

**Tests** (`server.test.ts`, using `app.request()`, scripted models and the fake backend): 401 with no token, a wrong token, or the backend token; 413 and 400; 200 with a paid outcome for the Karoo invoice; 409 for concurrent same-ID requests; `createAgentServer` throws if config holds a seed; a log-capture test confirms the invoice text never appears in log output.

**Prompt**

```text
Ticket T12: run the agent as its own HTTP service.
Follow the Shucamoxa ticket workflow in CLAUDE.md. Branch: feat/t12-agent-http-service.

Read .scratch/shucamoxa/spec.md "Process isolation" and "What others need from the agent". The backend (W4)
relays uploaded invoices to this service and writes the returned explanation into the audit log; the agent
never writes the log itself.

Tests first in services/agent/test/server.test.ts, using app.request(), scriptedModel and fakeBackend:
1. POST /agent/invoices with no token, a wrong token, or the agent's BACKEND token -> 401, and the
   planner model is never called.
2. Body over 1 MB -> 413; malformed JSON -> 400 with a short message and no stack trace.
3. Valid request {invoiceId: "inv_1", text: <Karoo invoice>} -> 200 {outcome, explanation}, where
   explanation parses as AgentExplanation and decision is "paid".
4. Two concurrent requests with the same invoiceId -> one 200 and one 409.
5. GET /health -> {ok: true}, with no config values in the body.
6. createAgentServer with an env containing AGENT_SEED -> throws (reuse T09's loader).
7. Capture the logger output during test 3 and assert it contains no line of the invoice text and no token.

Implement:
- Add hono and @hono/node-server to services/agent.
- src/server.ts exports createAgentServer({config, extractionModel, plannerModel, fetch?, logger?}).
  Use hono/body-limit (1 MB), a constant-time bearer check (crypto.timingSafeEqual on equal-length
  buffers) for AGENT_INBOUND_TOKEN, a strict Zod body schema, and an in-process serial queue plus an
  in-flight Set for the 409.
- src/main.ts: load config (T09 loader), build models with modelFromConfig, serve on AGENT_HOST
  (default 127.0.0.1) and AGENT_PORT (default 8790). Exit non-zero with the config error message on failure.
- Map AgentOutcome to AgentExplanation in one pure function and unit-test it.
- Add "start" and "dev" scripts (tsx). Add AGENT_INBOUND_TOKEN, AGENT_HOST and AGENT_PORT to the T09
  allowlist and .env.example.
- Structured logs: invoiceId, decision, ruleCode, durationMs. Never text, tokens or model output.
Commit subject: feat(agent): HTTP service with authenticated process-invoice endpoint (T12)
```

## Comments
