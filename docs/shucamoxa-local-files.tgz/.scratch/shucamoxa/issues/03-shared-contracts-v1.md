# T03 · Shared contracts v1

Status: resolved
Blocked by: 01
Branch: feat/t03-shared-contracts-v1
Owner: Cam drafts (W0), squad approves
Priority: P0
Due: Thu 23:00

**Branch** `feat/t03-shared-contracts-v1` · **Owner** Cam drafts, squad approves · **P0** · **Depends on** T01 · **Due** Thu 23:00

**Why:** this is the one item that blocks everyone. Each workstream should import types from here instead of inventing its own, and putting the log hash and money maths here means W2, W3, W4 and W5 can't disagree about them.

**Acceptance criteria** (everything below is exported from `@shucamoxa/shared`)

- [ ] **Constrained strings:** `InvoiceNumber` (`^[A-Za-z0-9][A-Za-z0-9._/-]{0,63}$`), `SupplierId` (`^sup_[a-z0-9_]{1,48}$`), `SupplierName` (1 to 120 characters, no control characters), `Reason` (1 to 200 characters, no control characters or angle brackets) and `XrplAddress` (classic address with checksum checked via `ripple-address-codec`).
- [ ] **Money:** `NonNegativeAmount` (allows `"0.00"`), `toCents(amount): bigint`, `fromCents(bigint): string`, `compareAmounts` and `addAmounts`. No floats anywhere.
- [ ] `PayRequest` uses the constrained strings and stays strict.
- [ ] **Agent-facing reads:** `Rules` (GET /rules, with `suppliers: [{id, name}]` as a strict object that has no address field), `SupplierLookup` (`{supplierId, name, confidence 0..1}` or `{notFound: true}`), `LogFilter` and `LogEntry`.
- [ ] **Approvals:** `ApprovalRequest` as a discriminated union (`supplier`: name, address or null, evidence, invoiceNumber; `payment`: invoiceNumber, supplierId, amount, reason) and `ApprovalResponse`.
- [ ] **Policy:** `CosignRequest` and `CosignResponse`, refined so `allow` requires `ruleCode: OK` plus `policySignedBlob`, and `block` requires a non-OK code and no blob.
- [ ] **Explanation:** `AgentExplanation` `{decision, ruleCode, explanation, invoiceNumber}` with decisions `paid`, `blocked`, `awaiting_owner` and `needs_review`.
- [ ] **Enums:** `LogEvent` (the 13 events in the spec) and `Actor` (`agent`, `payment`, `policy`, `owner`, `system`).
- [ ] **Constants:** `RLUSD_CURRENCY_HEX`, `RLUSD_TESTNET_ISSUER`, `XRPL_TESTNET_WSS`, `MEMO_TYPE = "shucamoxa/log"`, `LAST_LEDGER_WINDOW = 20`, `RATE_LIMIT = {count: 5, windowMs: 60000}`, `RESERVATION_TTL_MS = 120000` and `GENESIS_HASH` (64 zeros).
- [ ] **Hash chain:** `canonicalJson` (sorted keys; throws on `undefined`, functions, non-integer or unsafe numbers), `hashLogEntry(prevHash, entryWithoutHash)` (SHA-256 hex via Web Crypto, so the dashboard can run it in the browser) and `verifyChain(entries)` (returns the first bad `seq` or `null`). Also `toHex` and `fromHex` for memos.
- [ ] Existing agent tests still pass without edits.

**Tests:** a table-driven accept/reject test for every constrained string (including Unicode lookalikes, control characters and 65-character invoice numbers); cents round-trips, including `"0.01"` and the 12-digit maximum; `canonicalJson` giving the same output for objects whose keys were inserted in a different order, and refusing `30.5`; `verifyChain` catching an edited row, a deleted row, swapped rows and a wrong genesis hash; a known-answer hash test (fixed input, fixed expected hex) so every service can check itself against it; every `CosignResponse` refinement.

**Merge rule:** this is the one ticket that does not auto-merge. Open the PR, post it in the squad chat, and merge only after every workstream owner approves.

**Prompt**

```text
Ticket T03: shared contracts v1 in packages/shared. Due 23:00 tonight: it blocks every workstream.
Follow the Shucamoxa ticket workflow in CLAUDE.md, EXCEPT step 5.6: open the PR, then stop. Don't merge;
the squad must approve first. Branch: feat/t03-shared-contracts-v1.

Read .scratch/shucamoxa/spec.md sections "Tool contracts", "Policy service spec", "Data model and
audit log" and "Payment service and XRPL setup". Keep every existing export working: the agent uses
Amount, PayRequest, PayResult, RuleCode, ExtractedInvoice and ruleExplanation.

Split packages/shared/src into small modules (money.ts, ids.ts, agent-api.ts, approvals.ts, policy.ts,
log.ts, constants.ts) re-exported from index.ts. Add, with Zod 4:
- Constrained strings: InvoiceNumber /^[A-Za-z0-9][A-Za-z0-9._/-]{0,63}$/, SupplierId
  /^sup_[a-z0-9_]{1,48}$/, SupplierName (1-120 chars, no control chars), Reason (1-200 chars, no control
  chars, no < or >), XrplAddress (classic address, checksum verified with ripple-address-codec's
  isValidClassicAddress; add that one dependency and say why in the PR).
- Money: NonNegativeAmount (same format as Amount but allows zero), toCents -> bigint, fromCents,
  compareAmounts, addAmounts. Never use Number or floats for money.
- PayRequest: switch fields to the constrained strings; it stays a strictObject.
- Rules (GET /rules): perPaymentCap Amount, totalBudget Amount, spent/reserved/remaining
  NonNegativeAmount, periodStart ISO date string, killSwitch boolean, suppliers: array of
  strictObject {id: SupplierId, name: SupplierName}.
- SupplierLookup: {supplierId, name, confidence: number 0..1} | {notFound: true}.
- LogFilter {supplierId?, from?, to?, status?}, LogEntry {seq, ts, actor, event, invoiceNumber|null,
  supplierId|null, amount|null, ruleCode|null, explanation, txHash|null, ledgerResult|null, prevHash, hash}.
- ApprovalRequest: discriminated union on kind: "supplier" {name, address: XrplAddress|null, evidence,
  invoiceNumber} | "payment" {invoiceNumber, supplierId, amount, reason}. ApprovalResponse
  {approvalId, status: "pending"}.
- CosignRequest {txJson: record, agentSignedBlob: hex string, request: {supplierId, amount,
  invoiceNumber, logEntryHash: 64-hex}}. CosignResponse {decision: allow|block, ruleCode, reason,
  policySignedBlob?}, refined: allow => ruleCode OK and blob present; block => ruleCode not OK, no blob.
- AgentExplanation {decision: paid|blocked|awaiting_owner|needs_review, ruleCode: RuleCode|null,
  explanation, invoiceNumber: InvoiceNumber|null}.
- LogEvent enum with the 13 events in the spec; Actor enum agent|payment|policy|owner|system.
- Constants: RLUSD_CURRENCY_HEX "524C555344000000000000000000000000000000", RLUSD_TESTNET_ISSUER
  "rQhWct2fv4Vc4KRjRgMrxa8xPN9Zx9iLKV", XRPL_TESTNET_WSS "wss://s.altnet.rippletest.net:51233",
  MEMO_TYPE "shucamoxa/log", LAST_LEDGER_WINDOW 20, RATE_LIMIT {count: 5, windowMs: 60000},
  RESERVATION_TTL_MS 120000, GENESIS_HASH = "0".repeat(64).
- Hash chain: canonicalJson(value) with recursively sorted keys; throw on undefined, functions, NaN,
  Infinity and any number that isn't a safe integer (money must be strings). hashLogEntry(prevHash,
  entryWithoutHash) = SHA-256 hex of prevHash + canonicalJson(entry), using globalThis.crypto.subtle so it
  works in Node 20+ and the browser. verifyChain(entries) returns the first bad seq or null. toHex/fromHex
  helpers for memo fields.

Tests first, in packages/shared/test/: table-driven accept/reject for every constrained string
(include fullwidth and zero-width characters, control chars, a 65-char invoice number, an address with
a bad checksum); cents round-trips ("0.01", "30", "30.00", the 12-digit max); canonicalJson stable across
key order and refusing 30.5; verifyChain catching an edited row, a deleted row, two swapped rows and a
bad genesis; a known-answer test with a fixed entry and its expected hash hex (compute it once with
node:crypto in the test so the expected value is independent of the implementation); every
CosignResponse refinement.

The existing agent tests must pass with no edits. If a stricter PayRequest breaks one, stop and tell me.
Commit subject: feat(shared): contracts v1 for agent, policy, payment, log and dashboard (T03)
In the PR body, add a table of every export and the workstream that consumes it, so the squad can review fast.
```

## Comments
- 2026-11-13 02:44 SAST: merged as PR #6 (pending squad review). Review: 2 should-fix + 4 nits fixed.
