# T10 · Timeouts, redirect and size limits (G10)

Status: resolved
Blocked by: 01
Branch: fix/t10-agent-timeouts-and-limits
Owner: Cam
Priority: P1
Due: Fri 10:00

**Branch** `fix/t10-agent-timeouts-and-limits` · **Owner** Cam · **P1** · **Depends on** T01 · **Due** Fri 10:00

**Why:** if the laptop sleeps or the backend hangs mid-recording, the agent must fail closed and fast, not freeze the demo.

**Acceptance criteria**

- [ ] Backend calls use `AbortSignal.timeout(10_000)`, or 30 s for `POST /payments` since it waits for ledger validation, and `redirect: "error"`.
- [ ] Response bodies over 256 KB are refused (read with a byte counter, not `res.json()` on an unbounded body). `query_log` results are capped to 50 entries client-side.
- [ ] Model calls pass `abortSignal: AbortSignal.timeout(120_000)` (from the spec). The whole run has a deadline of 300 s.
- [ ] Any timeout produces `needs_review` with a reason naming the stage. A timed-out `POST /payments` is recorded as "payment outcome unknown, check the activity log" and is never retried.

**Tests** (use injected timeouts so tests run in milliseconds, not real waits): the G10 probe (a hanging `GET /rules`) returns `needs_review` quickly; a hanging pay gives the "outcome unknown" reason and exactly one payment request; a 300 KB response is refused; a 302 redirect is refused and the `Authorization` header never reaches the redirect target; a model that never answers gives `needs_review`.

**Prompt**

```text
Ticket T10: timeouts, redirect refusal and response size limits in the agent.
Follow the Shucamoxa ticket workflow in CLAUDE.md. Branch: fix/t10-agent-timeouts-and-limits.

The gap (reproduced, G10): a fetch that never resolves on GET /rules leaves processInvoice hanging
forever. There is no AbortSignal on backend calls or model calls, though the spec says 120 s.

Make every limit injectable (a Limits object in BackendDeps and AgentDeps, defaulting to: backend
10_000 ms, payments 30_000 ms, model 120_000 ms, run 300_000 ms, maxBody 262_144 bytes, maxLog 50), so
tests can use tiny values instead of fake timers fighting the AI SDK.

Failing tests first (new services/agent/test/limits.test.ts):
1. GET /rules never resolves, backend timeout 20 ms -> needs_review within 500 ms of real time.
2. POST /payments never resolves -> needs_review whose explanation says the payment outcome is unknown
   and to check the activity log; exactly one POST /payments was sent.
3. GET /log returns a 300 KB body -> treated as a backend error; nothing of it reaches the model.
4. GET /log returns 80 entries -> the model sees at most 50.
5. Backend answers 302 to another host -> refused; the fake records no request to that host.
6. The extraction model never resolves (a scriptedModel turn that awaits forever) -> needs_review.
7. The planner never resolves -> needs_review, zero payments.

Implement in src/backend.ts (signal, redirect: "error", a bounded body reader over res.body) and
src/agent.ts / src/extraction.ts (abortSignal on generateText, plus an overall run deadline with
AbortSignal.any). Map AbortError/TimeoutError to needs_review with a stage name; never retry pay.
Run the break-it check.
Commit subject: fix(agent): fail closed on slow or oversized backend and model responses (T10)
```

## Comments
- 2026-11-13: merged https://github.com/Xhanti-mbasa/myrmidons-agentic-finance/pull/18 (3ccb949)
