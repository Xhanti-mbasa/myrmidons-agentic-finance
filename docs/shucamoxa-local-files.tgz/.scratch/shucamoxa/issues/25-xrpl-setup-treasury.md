# T25 · Treasury setup script (multisig, master key off)

Status: ready-for-agent
Blocked by: 03
Branch: feat/t25-xrpl-setup-treasury
Owner: W3
Priority: P0
Due: Fri 10:00

**Branch** `feat/t25-xrpl-setup-treasury` · **Owner** W3 · **P0** · **Depends on** T03 · **Due** Fri 10:00

**Why:** this is your "use of XRPL" score and the ledger layer of the kill switch. The order of steps matters: the trustline must exist before the master key is disabled, and the signer list must exist before `asfDisableMaster` is valid.

**Acceptance criteria**

- [ ] `scripts/setup-treasury.ts` refuses any network other than testnet (URL allowlist and `server_info` network ID).
- [ ] It funds treasury, agent, policy, owner, supplier A, supplier B and an unknown supplier from the faucet, and sets RLUSD trustlines on the treasury and all three suppliers.
- [ ] It pauses for the human step (claim test RLUSD at tryrlusd.com for the treasury) and polls `account_lines` until the balance arrives. It warns if the treasury holds more than budget plus 25%, since a small balance is the spec's mitigation for a compromised service.
- [ ] `SignerListSet`: quorum 2; agent weight 1, policy weight 1, owner weight 2. It then confirms the list through `account_objects` before submitting `AccountSet` with `asfDisableMaster`.
- [ ] It proves the master key is off: a single-signed payment with the treasury's master key is rejected, and the result code is printed.
- [ ] It sends one 1.00 RLUSD multisigned payment (agent plus policy) to supplier A and prints the hash with a testnet.xrpl.org link (Technical Foundation Evidence).
- [ ] Seeds go to each service's own env file with permissions `0600`: `services/payment/.env` (agent seed), `services/policy/.env` (policy seed) and `secrets/owner-dev.env` (owner dev seed). Addresses only go to `secrets/setup-output.json`. No seed is ever printed or put in any other file.
- [ ] It's resumable from `secrets/setup-state.json` and won't overwrite an existing seed without `--force`.

**Tests:** the transaction builders (`TrustSet`, `SignerListSet`, `AccountSet`) are pure and unit-tested offline; the network guard refuses mainnet and devnet URLs; a `--dry-run` prints the plan with no network calls; captured stdout from a run with stubbed network calls contains no seed; the env writer sets `0600` and refuses to overwrite.

**Prompt**

```text
Ticket T25: one-time XRPL Testnet treasury setup - multisig signer list, master key disabled, evidence tx.
Follow the Shucamoxa ticket workflow in CLAUDE.md. Branch: feat/t25-xrpl-setup-treasury.

Read .scratch/shucamoxa/spec.md "Payment service and XRPL setup" (accounts, setup script, signing flow).
Use the RLUSD constants and XRPL_TESTNET_WSS from @shucamoxa/shared. Use the XRPL docs MCP
(mcp.xrpledger.ai) if it's available to you, for accurate xrpl.js calls.

Tests first (scripts/test/setup-treasury.test.ts, offline):
1. buildTrustSet, buildSignerListSet({agent, policy, owner}) and buildDisableMaster are pure and produce
   exactly: TrustSet to RLUSD issuer/currency hex; SignerListSet with SignerQuorum 2 and weights agent 1,
   policy 1, owner 2; AccountSet SetFlag asfDisableMaster.
2. assertTestnet refuses mainnet (wss://xrplcluster.com, wss://s1.ripple.com) and devnet URLs, and a
   server_info whose network_id isn't testnet's (1).
3. writeServiceEnv writes mode 0600, refuses to overwrite an existing key without force, and only writes
   to the three allowed paths.
4. A full run with an injected fake client: captured stdout and stderr contain none of the generated seeds.
5. --dry-run makes zero client calls.

Implement scripts/setup-treasury.ts (run with tsx) in resumable steps recorded in
secrets/setup-state.json: assertTestnet; fund 7 wallets with client.fundWallet; TrustSet on treasury and
the 3 suppliers; prompt the human to claim test RLUSD at tryrlusd.com for the treasury address and poll
account_lines every 10 s until it arrives (warn if it's more than total budget + 25%); SignerListSet;
confirm the list via account_objects; AccountSet asfDisableMaster; prove master is disabled (a single-signed
payment with the treasury seed must fail; print the engine result); send a 1.00 RLUSD multisigned payment
(autofill(tx, 2), wallet.sign(tx, true) by agent and policy, multisign, submitAndWait) to supplier A and
print the hash and https://testnet.xrpl.org/transactions/<hash>.
Write seeds only to services/payment/.env (AGENT_SEED), services/policy/.env (POLICY_SEED) and
secrets/owner-dev.env (OWNER_DEV_SEED); addresses to secrets/setup-output.json. secrets/ is already
gitignored; check it. Never print a seed. Don't run it against the network in this ticket unless I say
so; just show me the dry run.
Commit subject: feat(xrpl): resumable testnet treasury setup with multisig and master key disabled (T25)
```

## Comments
