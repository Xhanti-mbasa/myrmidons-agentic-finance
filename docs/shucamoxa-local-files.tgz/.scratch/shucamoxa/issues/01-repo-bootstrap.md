# T01 · Land the agent, tests and fixtures in the shared repo

Status: resolved
Blocked by: none
Branch: chore/t01-repo-bootstrap
Owner: Cam (W1)
Priority: P0
Due: Thu 22:30

**Branch** `chore/t01-repo-bootstrap` · **Owner** Cam · **P0** · **Depends on** none · **Due** Thu 22:30

**Why:** every other ticket branches from `main`, and the archive's `.gitignore` and `README.md` match the repo's exactly, so this is a clean add.

**Acceptance criteria**

- [ ] Workspace files (`package.json`, `pnpm-workspace.yaml`, `pnpm-lock.yaml`, `tsconfig.json`, `vitest.config.ts`), `packages/shared`, `services/agent` and `fixtures/invoices` are committed exactly as in the archive.
- [ ] `scripts/model-smoke-test.ts` is added from the project files.
- [ ] The root `package.json` gains `"typecheck": "tsc -p ."`, `"packageManager"` (the pnpm version in use) and `"engines": {"node": ">=20"}`. `.nvmrc` holds `22`.
- [ ] `services/agent/.env.example` lists `MODEL_BASE_URL`, `MODEL_NAME`, `MODEL_API_KEY`, `MODEL_FALLBACK_HOST`, `BACKEND_URL` and `AGENT_BACKEND_TOKEN` with obvious placeholder values, and nothing else.
- [ ] The README gets a short "Develop" section: Node 22, `pnpm install`, `pnpm typecheck`, `pnpm test`.
- [ ] `pnpm install --frozen-lockfile && pnpm typecheck && pnpm test` passes: 102 tests passing, 24 eval tests skipped.
- [ ] No local-only path is tracked (workflow step 4).

**Tests:** none new. The existing suite must pass unchanged.

**Out of scope:** any behaviour change. The security fixes come in T04 to T11.

**Prompt**

```text
Ticket T01: land the W1 agent, its tests and the demo fixtures in the shared repo.
Follow the Shucamoxa ticket workflow in CLAUDE.md. Branch: chore/t01-repo-bootstrap.

The unzipped archive is at <PATH_TO_UNZIPPED>/repo (ask me for the path if it's missing).
The smoke test is at <PATH_TO>/model-smoke-test.ts.

1. Copy these from the archive into the repo root, unchanged: package.json, pnpm-workspace.yaml,
   pnpm-lock.yaml, tsconfig.json, vitest.config.ts, packages/shared/, services/agent/, fixtures/.
   The archive's .gitignore and README.md are identical to the repo's, so leave those two alone.
2. Copy model-smoke-test.ts to scripts/model-smoke-test.ts, unchanged.
3. In the root package.json add: "typecheck": "tsc -p .", a "packageManager" field with the pnpm
   version you're running, and "engines": {"node": ">=20"}. Add .nvmrc containing 22.
4. Create services/agent/.env.example with exactly these names and placeholder values:
   MODEL_BASE_URL=http://100.x.y.z:11434/v1, MODEL_NAME=replace-me, MODEL_API_KEY=,
   MODEL_FALLBACK_HOST=, BACKEND_URL=http://127.0.0.1:8787, AGENT_BACKEND_TOKEN=replace-me.
   Add a comment line: the agent must never hold a seed, key or database URL; startup refuses them.
5. Add a short "Develop" section to README.md (Node 22, pnpm install, pnpm typecheck, pnpm test,
   and that services/agent/TESTING.md explains the test design). Don't describe unbuilt features.
6. Run pnpm install --frozen-lockfile, pnpm typecheck and pnpm test. Expect 102 passed and
   24 skipped. Don't change any source or test file to get there; if something fails, stop and tell me.

This ticket changes no behaviour, so skip the TDD and mutation steps. Then finish per the workflow.
Commit subject: chore(repo): add W1 agent, shared contracts and demo fixtures (T01)
```

## Comments
- 2026-11-12 23:50 SAST: merged as PR #2 (squash 7e90d79).
