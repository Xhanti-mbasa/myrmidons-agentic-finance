# T26 · Payment service: build, co-sign, submit, verify

Status: ready-for-agent
Blocked by: 22, 25, 28, 29
Branch: feat/t26-payment-service
Owner: W3
Priority: P0
Due: Fri 12:00

**Branch** `feat/t26-payment-service` · **Owner** W3 · **P0** · **Depends on** T22, T25, T28, T29 · **Due** Fri 12:00

**Why:** this is the only process holding the agent key. It has to be idempotent, never trust what it's told, and never pay twice when a submit times out.

**Acceptance criteria**

- [ ] `services/payment` listens on `127.0.0.1:8792`. `POST /payments` accepts only `PAYMENT_CALLER_TOKEN` (held by the API), parses `PayRequest`, and returns `PayResult`.
- [ ] It's idempotent on `invoiceNumber`: a repeat returns the stored result. A concurrent duplicate waits for the first or gets the same result, and there's never a second submit.
- [ ] It looks up the supplier's address and tag from the rules store (read role). Unknown, pending or removed suppliers are blocked with `SUPPLIER_NOT_APPROVED` without signing anything.
- [ ] It writes the pending `payment_requested` entry through T29's log writer, builds the `Payment` with the entry hash in the memo, calls `autofill(tx, 2)`, caps `LastLedgerSequence` at current + 20, and aborts if `Fee` exceeds `MAX_FEE_DROPS`.
- [ ] It signs with the agent key (multisign mode), calls `POST /cosign`, and checks that `policySignedBlob` decodes to the same transaction signed by `POLICY_ACCOUNT` before combining with `multisign` and calling `submitAndWait`.
- [ ] Success means `meta.TransactionResult === "tesSUCCESS"` **and** `meta.delivered_amount` equals the requested currency, issuer and value in cents. Then it settles the reservation and logs `payment_settled`. Anything else releases the reservation, logs `payment_failed`, and returns `blocked` with `LEDGER_REJECTED` and the hash.
- [ ] If the submit times out, it doesn't release. It polls the transaction by hash until `LastLedgerSequence` has passed, then settles or releases. If the policy service is unreachable, it returns HTTP 503 (the agent treats that as `needs_review` and never retries).
- [ ] Startup refuses non-testnet `XRPL_WSS` and refuses if the env holds `POLICY_SEED` or the owner seed.

**Tests** (an injected `XrplClient` interface, real offline signing, a fake policy): settled happy path; a policy block passes its rule code through and nothing is submitted; `tecPATH_PARTIAL` gives `LEDGER_REJECTED` with the reservation released; a `delivered_amount` mismatch gives `LEDGER_REJECTED`; a repeat invoice means one submit; 10 concurrent requests for the same invoice mean one submit; a timeout then a later validated success means settled, with no second submit; a tampered policy blob (a different transaction) means no submit; the agent's token gets 401; policy down gives 503; no seed in logs. Optionally, `RUN_TESTNET=1` runs one real payment.

**Prompt**

```text
Ticket T26: payment service - the only process that holds the agent key.
Follow the Shucamoxa ticket workflow in CLAUDE.md. Branch: feat/t26-payment-service.

Read .scratch/shucamoxa/spec.md "Payment request flow", "Signing flow" and "Budget reservation". Routing:
the agent never calls this service directly. W4's API validates the agent token and forwards POST /payments
here with PAYMENT_CALLER_TOKEN, so this service must refuse the agent's token.

Define an XrplClient interface (autofill, submitAndWait, request tx, ledger_current) so tests inject a
fake. Tests first in services/payment/test/payments.test.ts with real offline signatures:
1. Happy path -> {status: settled, ruleCode: OK, txHash, logId}; the log has payment_requested then
   payment_settled; the reservation is settled with the hash.
2. Policy blocks with OVER_PER_PAYMENT_CAP -> returned as blocked with that code; submitAndWait never
   called.
3. Ledger answers tecPATH_PARTIAL -> blocked LEDGER_REJECTED with txHash; reservation released;
   payment_failed logged.
4. tesSUCCESS but delivered_amount 29.00 for a 30.00 request -> blocked LEDGER_REJECTED and flagged in
   the log.
5. Same invoiceNumber twice -> the identical PayResult and exactly one submit; 10 concurrent -> one submit.
6. submitAndWait times out, then the tx is found validated with tesSUCCESS -> settled; never re-submitted.
7. policySignedBlob that decodes to a different tx, or is signed by a non-policy account -> nothing submitted.
8. Agent token or no token -> 401. Policy unreachable -> 503 and no submit.
9. Unknown or pending supplier -> blocked SUPPLIER_NOT_APPROVED; no signing.
10. Autofilled Fee above MAX_FEE_DROPS -> abort, nothing signed.
11. Startup refuses a mainnet XRPL_WSS and an env containing POLICY_SEED or OWNER_DEV_SEED; logs never
    contain AGENT_SEED.

Implement services/payment (Hono, xrpl, @shucamoxa/shared) following the spec flow, with a payments table
(T28 migration) for idempotency keyed on invoiceNumber, a per-invoice in-process lock, and settle/release
via the policy service's reservation endpoints (T22). Env in services/payment/.env: AGENT_SEED,
PAYMENT_CALLER_TOKEN, POLICY_URL, POLICY_CALLER_TOKEN, POLICY_ACCOUNT, TREASURY_ACCOUNT, XRPL_WSS, plus
the DB read/write role from T28. Add an opt-in test behind RUN_TESTNET=1 that makes one real 1.00
payment using the setup output, and tell me before running it.
Commit subject: feat(payment): idempotent multisig payment service with delivered-amount check (T26)
```

## Comments
