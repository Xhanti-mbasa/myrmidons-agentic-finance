# T37 · End-to-end pipeline tests and demo runner

Status: ready-for-agent
Blocked by: 12, 24, 26, 30
Branch: test/t37-e2e-and-demo-runner
Owner: Cam + W2/W3
Priority: P0
Due: Fri 17:30

**Branch** `test/t37-e2e-and-demo-runner` · **Owner** Cam with W2 and W3 · **P0** · **Depends on** T12, T24, T26, T30 · **Due** Fri 17:30

**Acceptance criteria**

- [ ] `test/support/ledger-sim.ts` implements the `XrplClient` interface offline. It keeps the treasury's signer list and RLUSD balances, verifies every multisig signature, enforces quorum (returning `tefBAD_QUORUM` or `tefBAD_SIGNATURE`), applies `SignerListSet`, rejects master-key signatures after `asfDisableMaster`, and fills `delivered_amount`.
- [ ] `test/e2e/pipeline.test.ts` boots the real agent (with a scripted model), API, policy and payment services on random local ports against a temp database and the simulator. It runs demo scenarios 1 to 6 and asserts outcomes, rule codes, log events, an intact chain, and that each settled payment's memo hash equals its log entry hash.
- [ ] Scenario 6 covers both layers: the kill-switch flag blocks with `KILL_SWITCH_ON`, then after `kill-switch revoke` a direct agent-plus-policy submit is rejected by the simulator.
- [ ] A cross-service isolation suite: the agent token is refused by policy, payment and every owner route; each service's env check refuses the other services' seeds; every service listens on 127.0.0.1 by default; no seed appears in any captured log line across the whole run.
- [ ] `pnpm dev:all` starts api, policy, payment, agent and web together (with concurrently). `scripts/run-demo.ts` runs scenarios 1 to 6 against the live testnet stack in order, pauses between them for the camera, and writes `docs/demo-evidence.md` with the tx hashes and explorer links.

**Tests:** the suites above are the tests. Also unit-test the simulator itself (quorum maths, a bad signature, master disabled), because a wrong simulator would make every e2e test meaningless.

**Prompt**

```text
Ticket T37: end-to-end pipeline tests on an offline ledger simulator, cross-service isolation tests, and
the live demo runner.
Follow the Shucamoxa ticket workflow in CLAUDE.md. Branch: test/t37-e2e-and-demo-runner.

Read .scratch/shucamoxa/spec.md "Payment request flow", "Kill switch", "Demo script" and "Threat model".

1. test/support/ledger-sim.ts implementing T26's XrplClient interface: state for accounts, the treasury
   signer list, the master-disabled flag and RLUSD balances. On submit, decode the blob, verify each Signer's
   signature with ripple-keypairs over encodeForMultisigning, sum weights against the quorum (tefBAD_QUORUM)
   and refuse unknown signers (tefBAD_SIGNATURE); apply SignerListSet and AccountSet asfDisableMaster;
   refuse master-key single signatures once disabled; check LastLedgerSequence; move balances and set
   delivered_amount. Unit-test the simulator first (quorum maths, a bad signature, an unknown signer,
   master disabled, an expired LastLedgerSequence).
2. test/e2e/pipeline.test.ts: start the real services in-process on random 127.0.0.1 ports with a temp DB
   (T28 migrations + seed) and the simulator; the agent uses scripted models. Scenarios 1-6 from
   expected.json: assert decision, ruleCode, the log events in order, verifyLog() is intact, and for each
   settled payment that the memo hash equals the payment_requested entry hash. Scenario 6: set the kill
   switch -> KILL_SWITCH_ON; run the revoke builder through the simulator; then sign a payment directly
   with the agent and policy keys and submit -> rejected.
3. test/e2e/isolation.test.ts: the agent token against policy /cosign, payment /payments and every owner
   route -> 401/403; each service's startup refuses the other services' seeds; default hosts are
   127.0.0.1; collect every log line from the whole pipeline run and assert none contains any seed.
4. Root script "dev:all" (concurrently) for api, policy, payment, agent and web.
5. scripts/run-demo.ts: against the live stack (BACKEND/AGENT URLs from env), run scenarios 1-6 in order,
   wait for Enter between each, print decision, rule code and explorer links, and write
   docs/demo-evidence.md (hashes and links only; no tokens). Testnet only. Don't run it against the
   network without asking me.
Commit subject: test(e2e): offline ledger simulator, full pipeline and isolation suites, demo runner (T37)
```

## Comments
