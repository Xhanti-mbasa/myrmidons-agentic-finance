# T28 · Database schema, migrations and seed

Status: ready-for-agent
Blocked by: 03
Branch: feat/t28-api-db-schema
Owner: W4
Priority: P0
Due: Fri 09:00

**Branch** `feat/t28-api-db-schema` · **Owner** W4 · **P0** · **Depends on** T03 · **Due** Fri 09:00

**Acceptance criteria**

- [ ] `packages/db` uses better-sqlite3 in WAL mode with `busy_timeout` 5,000 ms, plain SQL migrations in `packages/db/migrations/NNN_*.sql`, and `pnpm db:migrate`. The database file is `data/shucamoxa.db` (gitignored).
- [ ] Tables, all amounts stored as integer cents:
  - `rules`: `per_payment_cap_cents`, `total_budget_cents`, `period_start`, `kill_switch`, `updated_by`, `updated_at`;
  - `suppliers`: `id`, `name`, `xrpl_address`, `destination_tag`, `status` approved, pending or removed;
  - `approvals`: `id`, `kind`, `payload` JSON, `status`, `decided_by`, `decided_at`, `invoice_number`;
  - `reservations`: with a partial unique index on `invoice_number` where status is reserved or settled;
  - `payments`: the idempotency table for T26;
  - `audit_log`: exactly as in the spec;
  - `consumed_memo_hashes`: for T23.
- [ ] `CHECK` constraints: positive cents, a status enum, addresses 25 to 35 characters starting with `r`. Triggers make `audit_log` append-only (`BEFORE UPDATE` and `BEFORE DELETE` raise).
- [ ] Per-service repository modules (`rulesReadRepo`, `rulesWriteRepo`, `reservationsRepo`, `paymentsRepo`, `logRepo`) are the only way code touches tables. A dependency-cruiser rule stops `services/agent` importing `packages/db` at all.
- [ ] `pnpm db:seed` loads one business, Karoo and Zambezi (addresses from `secrets/setup-output.json`, or obvious placeholders if it's missing), a $50 cap, a $200 budget and the period starting today.

**Tests:** migrations apply on an empty file and are idempotent; the `UPDATE` and `DELETE` triggers fire on `audit_log`; the partial unique index allows a released duplicate and refuses a reserved one; `CHECK` refuses negative cents and bad statuses; the seed works without `setup-output.json`; dependency-cruiser fails when `services/agent` imports `packages/db` (a fixture test).

**Prompt**

```text
Ticket T28: database schema, migrations, repositories and demo seed.
Follow the Shucamoxa ticket workflow in CLAUDE.md. Branch: feat/t28-api-db-schema.

Database: use what the squad decided (decision D2). If it's not decided, use SQLite with better-sqlite3
and say so in the PR. Read .scratch/shucamoxa/spec.md "Data model and audit log" and "Budget reservation".

Tests first in packages/db/test/:
1. Migrations apply to an empty temp file; running them twice is a no-op.
2. audit_log: UPDATE and DELETE both throw (trigger); INSERT works.
3. reservations: insert reserved INV-1, then another reserved INV-1 -> constraint error; mark the first
   released, insert reserved INV-1 -> ok.
4. CHECK constraints refuse negative cents, an unknown status and an address not starting with r.
5. Seed runs with and without secrets/setup-output.json; with it, supplier addresses come from the file.
6. A dependency-cruiser rule forbidding services/agent -> packages/db; prove it with a fixture import that
   the rule catches (then remove the fixture).

Implement packages/db: better-sqlite3, WAL, busy_timeout 5000, foreign_keys on; numbered .sql
migrations and a tiny runner; the tables in the ticket (amounts as INTEGER cents; convert at the edge with
toCents/fromCents from @shucamoxa/shared); append-only triggers; repository modules per service so no
service writes raw SQL against another service's tables; root scripts db:migrate and db:seed; data/ in
.gitignore. Add dependency-cruiser with the agent rule to CI (pnpm depcheck).
Commit subject: feat(db): schema, append-only log triggers, repositories and demo seed (T28)
```

## Comments
