# T34 · Rules, suppliers and approvals screens

Status: ready-for-agent
Blocked by: 31, 33
Branch: feat/t34-web-rules-approvals
Owner: W5
Priority: P1
Due: Fri 13:00

**Branch** `feat/t34-web-rules-approvals` · **Owner** W5 · **P1** · **Depends on** T31, T33 · **Due** Fri 13:00

**Acceptance criteria**

- [ ] **Rules screen:** cap, budget, period, spent, reserved and remaining, all edited as decimal strings validated with shared schemas. This screen comes first in the recording.
- [ ] **Suppliers:** list, add (with `XrplAddress` validation and an optional tag) and remove. Changing an address shows that the supplier will need re-approval.
- [ ] **Approval cards:** supplier proposals show the proposed address in monospace with the last 6 characters highlighted and an input asking the owner to type them (T31). Payment approvals show amount, supplier and invoice, with the T32 signing step.
- [ ] All text from invoices, the agent or suppliers renders as plain text. No HTML or Markdown rendering.

**Tests:** form validation (a `30.001` cap is refused; a bad address is refused); an approval card whose evidence contains `<img src=x onerror=alert(1)>` renders it as literal text and creates no `img` element; the approve button stays disabled until the last 6 characters match; removing a supplier asks for confirmation.

**Prompt**

```text
Ticket T34: rules, suppliers and approval screens on the dashboard.
Follow the Shucamoxa ticket workflow in CLAUDE.md. Branch: feat/t34-web-rules-approvals.

Use the owner API from T31 through the T33 proxy, and the shared Zod schemas for every form.

Tests first (Testing Library):
1. Rules form: "30.001" and "-5" refused inline; "50" and "50.00" accepted; submitting calls
   PUT /api/owner/rules with string amounts (never numbers).
2. Supplier form: a bad-checksum address is refused; changing an existing supplier's address shows
   "needs re-approval" before saving.
3. Approval card with evidence "<img src=x onerror=alert(1)>" and supplier name "<b>x</b>": both render
   as literal text; container.querySelector("img, b") is null.
4. Supplier-proposal card: Approve is disabled until the typed last 6 characters match the proposed
   address; it then posts the confirmation to the decide endpoint.
5. Payment-approval card shows amount, supplier and invoice number, and the T32 signing instruction
   ("Run pnpm owner:sign <approvalId>" or the wallet option, per decision D4).

Implement the Rules and Approvals pages. Show spent, reserved and remaining from GET /api/rules. Render
every untrusted string with plain JSX text nodes only.
Commit subject: feat(web): rules, suppliers and approval screens with safe rendering (T34)
```

## Comments
