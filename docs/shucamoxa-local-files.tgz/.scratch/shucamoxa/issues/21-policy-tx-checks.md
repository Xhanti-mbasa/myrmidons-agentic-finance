# T21 · Policy checks 1–7 plus fee, flags and memo structure

Status: ready-for-agent
Blocked by: 20
Branch: feat/t21-policy-tx-checks
Owner: W2
Priority: P0
Due: Fri 11:00

**Branch** `feat/t21-policy-tx-checks` · **Owner** W2 · **P0** · **Depends on** T20 · **Due** Fri 11:00

**Why:** these are the spec's never-cut checks, plus three it misses. The worst of those is fee drain: without a fee cap, a payment carrying a 100 XRP fee passes all 12 checks.

**Acceptance criteria**

- [ ] Checks 3 to 7 exactly as the spec defines them, with amounts compared in cents via `toCents`. The RLUSD `value` may be written `"30"` or `"30.00"`.
- [ ] Check 4 compares `DestinationTag` both ways: if the supplier has one, the transaction must match it; if the supplier has none, the transaction must not have one.
- [ ] Check 6 becomes an allowlist. Allowed fields: `TransactionType`, `Account`, `Destination`, `DestinationTag`, `Amount`, `Fee`, `Sequence`, `LastLedgerSequence`, `Flags`, `Memos`, `SigningPubKey` (must be `""`), `NetworkID`. `Flags` may only be `0` or `tfFullyCanonicalSig`. Any other field gives `FORBIDDEN_TX_FIELDS`, which covers `SendMax`, `Paths`, `DeliverMin`, `DeliverMax`, `InvoiceID`, `TicketSequence` and `tfPartialPayment`.
- [ ] A new fee check: `Fee` at most `MAX_FEE_DROPS` (1,000 drops, in shared constants). Over that gives `FORBIDDEN_TX_FIELDS`.
- [ ] A new memo-structure check: exactly one memo, `MemoType` equal to `toHex(MEMO_TYPE)`, `MemoData` 64 hex characters, no `MemoFormat`. Anything else gives `MEMO_MISMATCH` (T23 adds the log match).
- [ ] `request.supplierId`, `amount` and `invoiceNumber` must agree with the decoded transaction (supplier address, amount, memo). Rules are always read from the rules store, never from the request.

**Tests:** one table-driven file with one passing case and at least one failing case per check, in the spec's order. Include the spec's named tests `blocks_partial_payment` and `blocks_destination_mismatch`, plus: XRP as a drops string; RLUSD from the wrong issuer; a fake currency `RLUSD` as 3+ characters instead of hex; amount `30.001`; `Amount` equal to the cap passes and one cent over fails; a 100 XRP fee; two memos; a missing destination tag; an extra destination tag; a removed supplier; a pending supplier. Also a precedence test: a transaction failing both check 4 and check 7 reports check 4's code.

**Prompt**

```text
Ticket T21: policy checks 3-7 plus the fee cap, flags allowlist and memo structure.
Follow the Shucamoxa ticket workflow in CLAUDE.md. Branch: feat/t21-policy-tx-checks.

Read .scratch/shucamoxa/spec.md "Checks, in order" and "Threat model". Add to the T20 pipeline, keeping
the spec's order and first-failure-wins.

Tests first: services/policy/test/checks.test.ts, a single it.each table of {name, mutate(tx|rules|request),
expect: RuleCode}, run through the full POST /cosign path with real offline signatures (re-sign after
every mutation so only the check under test can fail). Rows must include at least:
- pass: a valid 30.00 payment; a payment exactly at the 50.00 cap
- SUPPLIER_NOT_APPROVED: unknown supplierId; supplier status "pending"; status "removed"
- DESTINATION_MISMATCH: other address; supplier has tag 7, tx has none; supplier has none, tx has tag 7;
  tags differ (blocks_destination_mismatch)
- WRONG_ASSET: XRP drops string; RLUSD from another issuer; currency "RLUSD" spelled as plain text instead
  of hex; value "30.001"; value differing from request.amount
- FORBIDDEN_TX_FIELDS: tfPartialPayment (blocks_partial_payment); SendMax; Paths; DeliverMin; DeliverMax;
  InvoiceID; TicketSequence; any unknown field; Flags other than 0 or tfFullyCanonicalSig;
  Fee "100000000" (fee drain)
- OVER_PER_PAYMENT_CAP: 50.01
- MEMO_MISMATCH: no memo; two memos; wrong MemoType; MemoData not 64 hex; MemoFormat present
- precedence: fails both destination and cap -> DESTINATION_MISMATCH
- request/tx disagreement: request.amount 30.00 but tx 45.00 -> WRONG_ASSET

Implement each check as its own small pure function in src/checks.ts, added to CHECKS in spec order, with
the two new checks placed where the table expects. Amounts via toCents from @shucamoxa/shared only; add
MAX_FEE_DROPS = 1000 to shared constants. The field allowlist is a constant set; anything not in it fails.
Supplier address and tag come from RulesReader, never from the request.
Commit subject: feat(policy): checks 3-7, fee cap, field allowlist and memo structure (T21)
```

## Comments
