# T09 · Agent config: allowlist the environment and validate BACKEND\_URL (G7)

Status: resolved
Blocked by: 01
Branch: fix/t09-agent-config-hardening
Owner: Cam
Priority: P0
Due: Fri 09:00

**Branch** `fix/t09-agent-config-hardening` · **Owner** Cam · **P0** · **Depends on** T01 · **Due** Fri 09:00

**Why:** "the model never receives wallet keys" is your strongest claim to judges, and the current denylist misses the names people will actually use. A name denylist will always miss one, so the agent should load only an allowlisted file and scan values for key shapes.

**Acceptance criteria**

- [ ] The agent loads config only from `services/agent/.env`, via `node --env-file` or a tiny parser, plus `process.env` for the same allowlisted names: `MODEL_BASE_URL`, `MODEL_NAME`, `MODEL_API_KEY`, `MODEL_FALLBACK_HOST`, `BACKEND_URL`, `AGENT_BACKEND_TOKEN`, `AGENT_INBOUND_TOKEN`, `AGENT_PORT`, `AGENT_HOST`, `LOG_LEVEL`. An unknown key in the `.env` file is refused.
- [ ] Every variable in `process.env` is still scanned, and startup refuses when a name matches `SEED|SECRET|MNEMONIC|PRIVATE|PASSWORD|PASSWD|DATABASE|POSTGRES|^PG[A-Z]|SUPABASE|SERVICE_ROLE|(AGENT|OWNER|POLICY|TREASURY|WALLET|PAYMENT)_[A-Z_]*(KEY|TOKEN)$`, except the allowlisted names.
- [ ] It also refuses when any value contains an XRPL seed, a 64-hex key (optionally `ED` or `00` prefixed), a 12 or 24-word lowercase mnemonic, a `postgres://` or `postgresql://` URL, or a JWT whose payload has `role: service_role`. Matching finds these anywhere in the value, not only as the whole value.
- [ ] `BACKEND_URL` must be `http` on localhost or a Tailscale address, or `https` anywhere. It has no credentials in the URL, no trailing slash, and no path beyond `/`.
- [ ] Error messages name the variable and never echo any part of its value.
- [ ] A documented `AGENT_ALLOW_UNSAFE_ENV` escape hatch is **not** added.

**Tests:** every name from the G7 probe is refused; a seed embedded in JSON (`{"s":"sEd…"}`) is refused; `AGENT_KEY` holding a 66-character `ED` hex key is refused; `BACKEND_URL=http://evil.example` is refused; `https://api.example` and `http://127.0.0.1:8787` pass; `MODEL_API_KEY` and `AGENT_BACKEND_TOKEN` pass; no error message contains its value (checked across all cases); a dev shell's common variables (`GITHUB_TOKEN`, `NPM_TOKEN`, `PATH`, `HOME`) don't trip it.

**Prompt**

```text
Ticket T09: harden the agent's startup config so it can never run holding a key or DB credential.
Follow the Shucamoxa ticket workflow in CLAUDE.md. Branch: fix/t09-agent-config-hardening.

The gap (reproduced, G7): loadAgentConfig accepts AGENT_KEY (a 64-hex key), WALLET_SECRET, XRPL_SECRET,
SUPABASE_KEY, SUPABASE_SERVICE_KEY, POSTGRES_URL, PGPASSWORD, OWNER_KEY and PAYMENT_SERVICE_TOKEN, and
BACKEND_URL=http://evil.example. XRPL docs call a seed a "secret", so the current denylist misses
exactly the names people will use. Also, removing .trim() from the seed check made no test fail.

Failing tests first in services/agent/test/config.test.ts:
1. it.each over every G7 name -> throws /must not hold/.
2. Values: a seed inside JSON ('{"s":"sEdTM1uX8pu2do5XvTnutH6HsouMaM2"}'), a seed with surrounding
   spaces, "ED" + 64 hex, "00" + 64 hex, a 12-word and a 24-word lowercase mnemonic, a postgres:// URL
   under an innocent name, and a JWT whose payload has role service_role -> all refused.
3. BACKEND_URL: refuse http://evil.example, http://user:pw@127.0.0.1:8787, http://127.0.0.1:8787/api/;
   accept http://127.0.0.1:8787, http://localhost:8787, http://100.70.1.2:8787 and https://api.example.
4. Allowed: MODEL_API_KEY, AGENT_BACKEND_TOKEN, AGENT_INBOUND_TOKEN, GITHUB_TOKEN, NPM_TOKEN, PATH, HOME.
5. One test loops over every refusal case and asserts the error message contains no 6-character
   substring of the offending value.
6. loadAgentEnvFile(path): an unknown key in the file -> refused, naming the key.

Implement in src/config.ts: the allowlist constant, the name pattern from the ticket with allowlist
exceptions, value scanners that search within values (not anchored), BACKEND_URL validation sharing the
local/Tailscale logic with MODEL_BASE_URL, and loadAgentEnvFile. Don't add an override flag.
Update services/agent/.env.example if names changed.
Run the break-it check (including removing trim and un-anchoring).
Commit subject: fix(agent): allowlist env, scan values for keys, validate BACKEND_URL (T09)
```

## Comments
