# T18 · Run the model smoke test and close the gate

Status: ready-for-human
Blocked by: 01
Branch: chore/t18-model-smoke-gate
Owner: Cam + W7
Priority: P1
Due: Now

**Branch** `chore/t18-model-smoke-gate` · **Owner** Cam and W7 · **P1** · **Depends on** T01 · **Due** now (the gate was Thu 22:00)

**Why:** the plan depends on knowing tonight whether the laptop model can call tools. The smoke test also carries its own copy of the prompts, which has already drifted from the agent's.

**Human steps for W7 (ready-for-human)**

- [ ] The model server listens on the Tailscale IP only, for example `OLLAMA_HOST=100.x.y.z:11434`, not `0.0.0.0`.
- [ ] `tailscale funnel status` and `tailscale serve status` both show nothing exposed. The agent accepts `*.ts.net` hosts, and Funnel would make them public.
- [ ] `OLLAMA_KEEP_ALIVE=24h`, context length at least 8,192, laptop plugged in, sleep off.
- [ ] Send Cam the base URL, exact model tag, context length and the hours the laptop will be up.

**Acceptance criteria (Claude Code part)**

- [ ] Prompts and tool descriptions move into `services/agent/src/prompts.ts`. Both the agent and `scripts/model-smoke-test.ts` import them, so they can't drift. The smoke test stays runnable with `npx tsx` and nothing else.
- [ ] The smoke test gains `--json` output and a check that context length is at least 8,192 where the server reports it (Ollama `/api/show`).
- [ ] The results are recorded in the local ticket file (not committed): pass or fail per check, median latency, model tag.
- [ ] If the gate fails on tool confusion, T19 is the next ticket. If it fails on reachability or latency, switch to the hosted fallback.

**Prompt**

```text
Ticket T18: run the local-model smoke test against the teammate's laptop and record the gate result.
Follow the Shucamoxa ticket workflow in CLAUDE.md. Branch: chore/t18-model-smoke-gate.

1. Move the extraction and planner system prompts and the tool descriptions into
   services/agent/src/prompts.ts, export them, and use them from src/agent.ts and src/extraction.ts.
   No wording changes in this ticket: existing tests must pass untouched.
2. Make scripts/model-smoke-test.ts import its prompts and tool descriptions from that file, so they can't
   drift (it currently has 6 planner rules where the agent has 7). It must still run with only
   "npx tsx scripts/model-smoke-test.ts". Add a --json flag that prints the results as JSON. Add a check:
   if GET <base without /v1>/api/show for the model works (Ollama), fail when the context length is
   below 8192; otherwise print "context length: unknown".
3. Ask me for MODEL_BASE_URL and MODEL_NAME (and MODEL_API_KEY if any) and run the smoke test with them
   as environment variables for that one command only. Don't write them to any file. Show me the full
   output.
4. Tell me plainly: GATE PASSED or GATE FAILED, which checks failed and why, and the recommendation:
   tool confusion -> do T19; reachability or latency -> switch to the hosted fallback.
5. Append the result summary (no URLs or keys) to the local ticket file under ## Comments.
Then finish per the workflow for the code changes in steps 1-2.
Commit subject: chore(agent): share prompts with the smoke test and add gate checks (T18)
```

## Comments
