# T15 · Dev mock backend (fallback for W3 and W4)

Status: resolved
Blocked by: 03
Branch: feat/t15-dev-mock-backend
Owner: Cam
Priority: P1
Due: Fri 00:00

**Branch** `feat/t15-dev-mock-backend` · **Owner** Cam · **P1** · **Depends on** T03 · **Due** Fri 00:00

**Why:** the spec's fallbacks are JSON fixtures, a mock `POST /payments` and a local approvals queue. One small service covers all three. Its contract tests can then run unchanged against W4's real API, which catches drift between the two.

**Acceptance criteria**

- [ ] `services/mock-backend` (dev only; it refuses to start unless `SHUCAMOXA_MOCK=1`) implements `GET /rules`, `GET /suppliers?q=`, `POST /payments`, `POST /approvals` and `GET /log`, with every response parsed by its shared schema before sending.
- [ ] Seed data comes from `fixtures/demo-rules.json`: Karoo and Zambezi, a $50 cap and a $200 budget.
- [ ] Supplier lookup scores confidence by normalised token overlap. "Karoo Textiles (Pty) Ltd" scores at least 0.85 against Karoo; "Zambezi" scores below 0.85 against Karoo.
- [ ] `POST /payments` applies the policy rules in-process (kill switch, approved, cap, budget, duplicate, all in cents), is idempotent on `invoiceNumber`, and returns `MOCK` tx hashes that are clearly fake.
- [ ] Approvals append to `.mock/approvals.jsonl` (gitignored). The log is in memory and hash-chained with `hashLogEntry`.
- [ ] `POST /dev/kill-switch {on}` exists only in the mock and needs a separate `MOCK_OWNER_TOKEN`.
- [ ] `packages/shared/test-support/contract.ts` exports `agentApiContract(baseUrl, token)`, a Vitest suite reusable against W4's API (T30).

**Tests:** the contract suite passes against the mock; confidence thresholds; idempotency (the same invoice twice gives the same result and one log entry); parallel payments can't exceed the budget; the agent token can't call `/dev/kill-switch`; the mock refuses to start without `SHUCAMOXA_MOCK=1`.

**Prompt**

```text
Ticket T15: a dev-only mock backend so the agent runs end to end before W3/W4 exist.
Follow the Shucamoxa ticket workflow in CLAUDE.md. Branch: feat/t15-dev-mock-backend.

Read .scratch/shucamoxa/spec.md "Tool contracts", "Policy service spec" (checks 1, 3, 7, 8, 9) and
"What the agent needs from others" (the fallback column).

Tests first:
1. packages/shared/test-support/contract.ts: export agentApiContract(baseUrl, agentToken), a describe
   block that checks every agent-facing endpoint's response parses with the shared schema, GET /rules
   contains no r-address anywhere, GET /suppliers never returns an address, unknown routes are 404, and
   every write route other than POST /payments and POST /approvals refuses the agent token. Run it
   against the mock in services/mock-backend/test/contract.test.ts.
2. Lookup: "Karoo Textiles (Pty) Ltd" -> sup_karoo with confidence >= 0.85; "Zambezi" queried against
   Karoo's name -> < 0.85; "Atlas Freight" -> notFound.
3. POST /payments: same invoiceNumber twice -> the same PayResult, one log entry; 10 parallel 45.00
   payments with distinct invoice numbers -> total settled <= 200.00; kill switch on -> KILL_SWITCH_ON;
   amounts compared in cents.
4. POST /dev/kill-switch with the agent token -> 403; with MOCK_OWNER_TOKEN -> 200.
5. Starting without SHUCAMOXA_MOCK=1 -> throws.

Implement services/mock-backend with Hono, bound to 127.0.0.1:8787. Seed from fixtures/demo-rules.json
(Karoo sup_karoo and Zambezi sup_zambezi with obviously fake testnet-looking addresses that are never
returned to the agent). Confidence = normalised token overlap (lowercase, strip punctuation and the
words pty, ltd, limited, inc, co). Approvals append to .mock/approvals.jsonl; add .mock/ to .gitignore.
The log is an in-memory hash chain built with hashLogEntry from @shucamoxa/shared. Add a root script
"dev:mock" that sets SHUCAMOXA_MOCK=1. Put a loud README line: never deploy this.
Commit subject: feat(dev): mock backend and reusable agent API contract tests (T15)
```

## Comments
- 2026-11-13: merged https://github.com/Xhanti-mbasa/myrmidons-agentic-finance/pull/19 (679617a)
