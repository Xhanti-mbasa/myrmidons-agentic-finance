# T33 · Dashboard shell, login and security headers

Status: ready-for-agent
Blocked by: 03
Branch: feat/t33-web-shell-auth
Owner: W5
Priority: P1
Due: Fri 10:00

**Branch** `feat/t33-web-shell-auth` · **Owner** W5 · **P1** · **Depends on** T03 · **Due** Fri 10:00

**Acceptance criteria**

- [ ] `apps/web` is a Next.js App Router app with a login page, an authenticated layout (Rules, Approvals, Activity, Chat) and middleware that redirects to `/login` without a session.
- [ ] A server route `/api/[...path]` proxies to `API_URL`, forwarding only the session cookie and `Origin`. The only server env var is `API_URL`, and startup refuses any seed, key or token in the web env (reuse T09's scanner from `@shucamoxa/shared`).
- [ ] Headers on every response: a CSP with `default-src 'self'`, nonce-based scripts, `frame-ancestors 'none'` and `connect-src 'self'`; plus `X-Content-Type-Options: nosniff`, `Referrer-Policy: no-referrer` and a restrictive `Permissions-Policy`.
- [ ] ESLint with `react/no-danger` set to error, and no `dangerouslySetInnerHTML` anywhere.
- [ ] Until T31 lands, the UI runs against the T15 mock.

**Tests:** the proxy forwards the cookie and strips any `Authorization` header from the browser; the header config matches the snapshot above; the middleware redirects unauthenticated requests; lint fails on a fixture using `dangerouslySetInnerHTML`; the startup env check refuses `AGENT_SEED`.

**Prompt**

```text
Ticket T33: Next.js dashboard shell with owner login, an API proxy and strict security headers.
Follow the Shucamoxa ticket workflow in CLAUDE.md. Branch: feat/t33-web-shell-auth.

Read .scratch/shucamoxa/spec.md "Owner dashboard" rows and "Trust zones". The web app holds no token or
seed: it proxies browser requests to services/api (API_URL) with the owner's session cookie only.

Tests first (Vitest + Testing Library in apps/web/test/):
1. The proxy route handler forwards the cookie and Origin to API_URL, drops any Authorization header sent
   by the browser, and never forwards to a host other than API_URL (path traversal like
   /api/..%2f..%2fhttp:%2f%2fevil -> 400).
2. next.config headers(): a CSP with default-src 'self', frame-ancestors 'none', connect-src 'self';
   nosniff; Referrer-Policy no-referrer; Permissions-Policy denying camera, microphone and geolocation.
3. Middleware: no session cookie -> redirect to /login for every page except /login.
4. The env guard (reuse the T09 scanner, moved into @shucamoxa/shared if needed) refuses AGENT_SEED,
   POLICY_SEED, OWNER_DEV_SEED and AGENT_BACKEND_TOKEN in the web env.
5. ESLint: react/no-danger is an error; a fixture file using dangerouslySetInnerHTML fails lint (then delete
   the fixture).

Implement apps/web (Next.js App Router, TypeScript, no UI kit beyond plain CSS modules or Tailwind if
already installed): a login page posting to /api/owner/login; a layout with nav (Rules, Approvals,
Activity, Chat), each a placeholder; middleware; the proxy route; headers with a per-request nonce. Add
"dev:web" to the root scripts, and run it against the T15 mock until T31 is merged.
Commit subject: feat(web): dashboard shell with owner login, API proxy and security headers (T33)
```

## Comments
