# T13 · Streaming chat endpoint with tool events

Status: ready-for-agent
Blocked by: 08, 12
Branch: feat/t13-agent-chat-stream
Owner: Cam
Priority: P1
Due: Fri 13:00

**Branch** `feat/t13-agent-chat-stream` · **Owner** Cam · **P1** · **Depends on** T08, T12 · **Due** Fri 13:00

**Why:** W5's chat panel needs this by 13:00, and seeing the agent call `find_supplier`, `get_rules` and `pay` live is the clearest proof that it acts on its own.

**Acceptance criteria**

- [ ] `POST /agent/chat` with `{message}` (1 to 2,000 characters) returns `text/event-stream` using `streamText`.
- [ ] Event types: `tool` `{name, phase: "start"|"end", ok, refused?, ruleCode?}`, `text` `{delta}`, `summary` `{summary, payments}` (from T08), `error` `{message}`, `done`.
- [ ] Tool events never include arguments or results. Only `ruleCode` and `refused` leave the service.
- [ ] With the kill switch on, the stream is one `summary` with the kill-switch explanation, then `done`, and the model isn't called.
- [ ] The same auth, body limit and timeouts as T12. A client disconnect aborts the model call.
- [ ] `docs/agent-api.md` documents both endpoints and the event shapes for W5. This file is shared, not local.

**Tests:** parse the SSE stream for "Pay Karoo $30 now" and check the event order (`tool` events for `find_supplier`, `get_rules` and `pay`, then `text`, `summary`, `done`); no event contains an XRPL address, `supplierId` or `amount` in tool events; the kill-switch case; 401 without a token; abort on disconnect stops further model calls.

**Prompt**

```text
Ticket T13: streaming owner-chat endpoint with tool-call events for the dashboard.
Follow the Shucamoxa ticket workflow in CLAUDE.md. Branch: feat/t13-agent-chat-stream.

Build on T12's server and T08's chat guards. W5 (dashboard) consumes this, so the contract matters more
than the internals.

Tests first in services/agent/test/chat-stream.test.ts (parse the SSE body into events):
1. "Pay Karoo $30 now" with a scripted planner [find_supplier, get_rules, pay, text] -> events in order:
   tool(find_supplier start/end), tool(get_rules start/end), tool(pay start/end, ok: true), text deltas,
   summary {summary, payments: [settled]}, done.
2. No event anywhere contains an r-address, and tool events contain only {name, phase, ok, refused?,
   ruleCode?} (assert the exact key set).
3. Kill switch on -> exactly [summary, done]; the planner model has zero calls.
4. No token -> 401. Message of 2,001 chars -> 400.
5. A model that throws mid-stream -> an error event {message: "The agent could not finish."} then done,
   with no stack trace or provider message.
6. An aborted request stops the run: the scripted model records no further calls after the abort.

Implement in src/server.ts and src/agent.ts: a chatStream(message, signal) that uses streamText with the
T08 chat tools, wraps each tool's execute to emit start/end events, and ends with the deterministic
summary. Use Hono's streamSSE. Pass the request's abort signal through.
Write docs/agent-api.md (shared doc, committed) with both endpoints, auth, limits and every event shape,
with one example each.
Commit subject: feat(agent): streaming chat endpoint with redacted tool events (T13)
```

## Comments

## Notes carried from the T12 review (2026-11-13)
- Proposed re-scope (needs Cam's OK, conflicts with the current spec text): a single OpenAI-compatible `POST /v1/chat/completions` adapter over T12's internal `ownerChat({latestOwnerTurn})`, so Open WebUI can connect to the agent. Strip `system` turns and history before validation, and accept the `model` and `stream` fields. Stream in OpenAI SSE chunk format, carrying redacted tool events and the code-built summary as content.
- **Blocker to design for:** never let a response-shaping or schema failure hide a settled payment. If `payments` isn't empty, return them with a fixed, code-built reply, and cut the model text to the limit in code. Test: the model pays, then sends a reply of more than 20,000 characters; expect 200 with the payment.
- Abort the run when the client disconnects. Add an idempotency key for chat payments, because each run gets a fresh `CHAT-` number, so a retry can settle twice.
- When `agent.chat` throws after a pay settled (not a stall), report the payments the way the stall path does.
- Cap the queue length and return 429 past it.
