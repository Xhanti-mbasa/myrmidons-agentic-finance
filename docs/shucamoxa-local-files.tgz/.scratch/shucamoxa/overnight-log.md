# Overnight log

| Time | Ticket | Result | PR | Notes |
| --- | --- | --- | --- | --- |
| 23:50 | T01 | merged | #2 | copied as-is; no CI yet |
| 00:05 | T02 | merged | #3 | review: 2 should-fix + 3 nits fixed; CI green; human step: require checks on main |
| 02:44 | T03 | merged | #6 | pending squad review; review found 2 test gaps (float toCents, key order) + 4 nits, all fixed |
| 02:46 | T03b | merged | #7 | rename PayGuard→Shucamoxa in code; mechanical, self-reviewed diff; CI green |
| 03:00-05:00 | — | paused | — | usage limit hit at ~03:00; resumed T04 review, T06 and T09 builds at 05:00 |
| 05:04 | T04 | merged | #13 | review APPROVE; prompt rule 3 reworded; 21 new tests |
| 05:16 | T09 | merged | #14 | review: 4 should-fix (mnemonic false positive, 0x hex, seed in URL path, asyncpg/sb_secret) + 2 nits fixed; new dep @scure/bip39 (wordlist) |
| 05:26 | T06 | merged | #15 | review r1: 1 blocker (amount grounding) + 3 should-fix fixed; r2 APPROVE |
| 05:33 | T05 | merged | #16 | r1: blocker (address in free text) + 2 should-fix; r2: X/spaced address redaction; all fixed |

## 2026-11-13 afternoon
- Merged today: T16 #17 (4eeccaa), T10 #18 (3ccb949), T15 #19 (679617a). All Opus-built, Opus-reviewed.
- ~10:50 usage limit hit (reset 15:20). In flight at the time: T07 (rebasing on T10, fixing 2 review blockers), T08 (fixing review: currency allowlist, payee/approval binding), T06b (building), T12 (never started).
- 15:25 added CLAUDE.md §7 model fallback (Opus → sonnet → fable; no haiku for code).
- T12 built on Opus (default model) in /home/claude/wt-t12, commit b193fb5 on feat/t12-agent-http-service (not pushed); awaiting review.
- 15:47 T07 merged #23 (7ca8db5); CI fix #24 (96ade6b) merged (adversarial job: install mcp_gateway deps, retire SECRET-04). T12 sent back: drop /agent/chat (moved to T13). All Opus.
- T12 review changes applied on Opus: chat route and OwnerChat* removed, ownerChat seam kept, boundary tests added, rebased on 7ca8db5; commit dff134f (not pushed; remote branch still at b193fb5).
