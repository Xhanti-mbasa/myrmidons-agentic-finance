## Open decisions that change tickets

The tickets assume the default in the last column. If the squad decides otherwise, edit the named tickets before running them.

| ID | Decision | Tickets affected | Default the tickets assume |
| --- | --- | --- | --- |
| D1 | Owners for W2 to W7 | T20 to T38 | Unassigned; each prompt works for whoever runs it |
| D2 | Supabase or SQLite | T28, T31, T22 | SQLite with better-sqlite3, the spec's fallback and the faster build |
| D3 | Hosted fallback model: which provider, whose key | T17, T18 | Undecided. `MODEL_FALLBACK_HOST` must be named, and the key lives only in `services/agent/.env.fallback` |
| D4 | Owner key for the demo: Xaman on a phone, or a dev seed | T27, T32, T35 | Dev seed in `secrets/owner-dev.env` used only by scripts. More reliable to record; Xaman can be added later |
| D5 | Final demo numbers and budget period | T15, T16, T28 | $50 cap, $200 budget, period starting on the demo day |
| D6 | Where the demo runs | T12, T20, T26, T30, T37 | One laptop with every service on 127.0.0.1, reaching the model over Tailscale. Long-running services would need Railway or Fly, not Vercel functions |
| D7 | Auto squash-merge or human review | the workflow block | Auto squash-merge once CI is green, except T03 (squad approval) |

