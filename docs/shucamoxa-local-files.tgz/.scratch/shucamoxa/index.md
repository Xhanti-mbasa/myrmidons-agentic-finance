## Ticket index

Rows are grouped by workstream, so pick work by due time and the "Depends on" column, not by row order. Times are SAST. Gate 1 (Thu 23:00) is the shared contracts. Gate 2 (Fri 10:00) is the agent reading real rules. Gate 3 (Fri 18:00) is feature freeze. T18's 22:00 smoke-test gate has passed, so run it now.

| ID | Ticket | Branch | Owner | Priority | Depends on | Due |
| --- | --- | --- | --- | --- | --- | --- |
| T01 | Land the agent, tests and fixtures in the shared repo | `chore/t01-repo-bootstrap` | Cam (W1) | P0 | none | Thu 22:30 |
| T02 | CI, typecheck and secret scanning | `ci/t02-ci-and-secret-guardrails` | Cam | P0 | T01 | Thu 23:30 |
| T03 | Shared contracts v1 | `feat/t03-shared-contracts-v1` | Cam drafts (W0), squad approves | P0 | T01 | Thu 23:00 |
| T04 | Bind pay to the invoice's own supplier (G1, G9) | `fix/t04-agent-bind-supplier` | Cam | P0 | T03 | Fri 00:30 |
| T05 | Bind approvals and supplier proposals to the invoice (G3, G4) | `fix/t05-agent-bind-approvals` | Cam | P0 | T04 | Fri 01:30 |
| T06 | Ground extraction in the raw text; harden the tag neutraliser (G5, G11) | `fix/t06-extraction-grounding` | Cam | P0 | T03 | Fri 02:00 |
| T07 | Planner sees only constrained fields; cap free text (G2, G8) | `fix/t07-planner-input-minimisation` | Cam | P0 | T03 | Fri 08:30 |
| T08 | Chat payment guards (G6) | `fix/t08-chat-payment-guards` | Cam | P1 | T04 | Fri 09:30 |
| T09 | Agent config: allowlist env and validate BACKEND\_URL (G7) | `fix/t09-agent-config-hardening` | Cam | P0 | T01 | Fri 09:00 |
| T10 | Timeouts, redirect and size limits (G10) | `fix/t10-agent-timeouts-and-limits` | Cam | P1 | T01 | Fri 10:00 |
| T11 | Kill the surviving mutants; make TESTING.md accurate | `test/t11-agent-mutation-hardening` | Cam | P1 | T04 to T10 | Fri 11:00 |
| T12 | Agent HTTP service: process-invoice endpoint | `feat/t12-agent-http-service` | Cam | P0 | T09, T10 | Fri 12:00 |
| T13 | Streaming chat endpoint with tool events | `feat/t13-agent-chat-stream` | Cam | P1 | T08, T12 | Fri 13:00 |
| T14 | PDF text extraction and CLI invoice loader | `feat/t14-agent-pdf-and-cli` | Cam | P1 | T12 | Fri 12:30 |
| T15 | Dev mock backend (fallback for W3/W4) | `feat/t15-dev-mock-backend` | Cam | P1 | T03 | Fri 00:00 |
| T16 | Demo invoice PDFs and red-team pack | `feat/t16-demo-invoices` | Cam | P1 | T01 | Fri 10:00 |
| T17 | Real-model eval with report and new red-team fixtures | `test/t17-agent-eval-report` | Cam | P1 | T06, T16 | Fri 15:00 |
| T18 | Run the model smoke test and close the gate | `chore/t18-model-smoke-gate` | Cam + W7 | P1 | T01 | Now |
| T19 | Contingency: merge the two approval tools | `feat/t19-merged-approval-tool` | Cam | P2 | T18 fails on tool confusion | Fri 12:00 |
| T20 | Policy service: skeleton, auth, decode and verify | `feat/t20-policy-service-skeleton` | W2 | P0 | T03 | Fri 10:00 |
| T21 | Policy checks 1–7 plus fee, flags and memo structure | `feat/t21-policy-tx-checks` | W2 | P0 | T20 | Fri 11:00 |
| T22 | Atomic budget reservation and duplicate check | `feat/t22-policy-budget-reservation` | W2 | P0 | T21, T28 | Fri 12:00 |
| T23 | Stale tx, memo match and rate limit | `feat/t23-policy-stale-memo-rate` | W2 | P0 | T22, T29 | Fri 13:00 |
| T24 | Policy audit logging and red-team replay | `test/t24-policy-audit-and-redteam` | W2 | P0 | T23, T16 | Fri 15:00 |
| T25 | Treasury setup script (multisig, master off) | `feat/t25-xrpl-setup-treasury` | W3 | P0 | T03 | Fri 10:00 |
| T26 | Payment service: build, co-sign, submit, verify | `feat/t26-payment-service` | W3 | P0 | T22, T25, T28, T29 | Fri 12:00 |
| T27 | On-ledger kill switch and revocation proof | `feat/t27-ledger-kill-switch` | W3 | P0 | T25, T31 | Fri 15:00 |
| T28 | Database schema, migrations and seed | `feat/t28-api-db-schema` | W4 | P0 | T03 | Fri 09:00 |
| T29 | Hash-chained, append-only audit log | `feat/t29-audit-log-hash-chain` | W4 | P0 | T28 | Fri 10:00 |
| T30 | Agent-scoped read and propose endpoints | `feat/t30-api-agent-endpoints` | W4 | P0 | T28, T29 | Fri 10:00 |
| T31 | Owner auth, rules, suppliers, kill switch, approvals | `feat/t31-api-owner-endpoints` | W4 | P0 | T30 | Fri 12:00 |
| T32 | Owner-signed over-cap payment path | `feat/t32-owner-approved-payment` | W4 + W3 | P1 | T26, T31 | Fri 14:00 |
| T33 | Dashboard shell, login and security headers | `feat/t33-web-shell-auth` | W5 | P1 | T03 | Fri 10:00 |
| T34 | Rules, suppliers and approvals screens | `feat/t34-web-rules-approvals` | W5 | P1 | T31, T33 | Fri 13:00 |
| T35 | Kill switch and activity screen with "log intact" badge | `feat/t35-web-killswitch-activity` | W5 | P0 | T27, T29, T33 | Fri 15:00 |
| T36 | Chat panel and invoice upload | `feat/t36-web-chat-upload` | W5 | P1 | T13, T33 | Fri 16:00 |
| T37 | End-to-end pipeline tests and demo runner | `test/t37-e2e-and-demo-runner` | Cam + W2/W3 | P0 | T12, T24, T26, T30 | Fri 17:30 |
| T38 | README, recording and submission | `docs/t38-readme-and-submission` | W6 | P0 | T37 | Fri 23:00 |

