# Shucamoxa tickets (local only, never commit)

Live doc: https://claude.ai/artifact/QtC1kG7fEXvFB4V1voodoS

## How to use this

There are 38 tickets across W0 to W7. Each one has a branch name, acceptance criteria, the tests it must add, and a Claude Code prompt you can paste as-is. Run them by due time: T01 and T03 tonight (contracts are due at 23:00), the W1 hardening tickets T04 to T11 tonight, then everything else on Friday before the 18:00 freeze.

1. **One-time setup (about 5 minutes).** Paste the *Ticket workflow* block below into your local `CLAUDE.md`, which is already in `.git/info/exclude`. Every Claude Code session then follows the same branch, TDD, security, squash and PR rules, so the prompts stay short.
2. **Local ticket files.** Copy the ticket bundle to `.scratch/shucamoxa/` in your clone. It holds one file per ticket at `.scratch/shucamoxa/issues/NN-slug.md` (matching `docs/agents/issue-tracker.md`) plus a copy of the spec at `.scratch/shucamoxa/spec.md`. None of it is committed and none of it becomes a GitHub issue.
3. **Per ticket.** Open a fresh Claude Code session in the repo root and paste the ticket's prompt. It branches from `main`, writes failing tests first, implements, verifies, squashes to one commit, pushes, opens a PR, waits for CI and squash-merges.
4. **Teammates' tickets.** W2 to W6 tickets are written so whoever owns that workstream can run them the same way. They need the workflow block too: send it to them, not your local files.

**About the merge step:** the workflow squash-merges each PR once CI is green, because later tickets branch from `main` and depend on earlier ones. If the squad wants a human review on shared code, delete the last step of the workflow block and merge by hand.

**Priorities:** P0 means never cut (the spec's never-cut list plus the security fixes). P1 is needed for the demo. P2 is cut first if late.

