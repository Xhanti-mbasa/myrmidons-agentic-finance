## Agent skills

### Issue tracker

Issues and specs live as local markdown files under `.scratch/<feature>/`. See `docs/agents/issue-tracker.md`.

### Triage labels

Default five roles (needs-triage, needs-info, ready-for-agent, ready-for-human, wontfix), recorded as a `Status:` line in each issue file. See `docs/agents/triage-labels.md`.

### Domain docs

Single-context: one `CONTEXT.md` and `docs/adr/` at the repo root. See `docs/agents/domain.md`.
## Shucamoxa ticket workflow (local only, never commit this file)

Applies whenever a prompt says "Follow the Shucamoxa ticket workflow".

### 1. Start
- Read the ticket file `.scratch/shucamoxa/issues/<NN>-*.md` if it exists, and the spec sections it names in `.scratch/shucamoxa/spec.md`. Read `services/agent/TESTING.md` before touching any test.
- `git status` must be clean. Run `git fetch origin && git switch main && git pull --ff-only`, then `git switch -c <branch named in the prompt>`. If that branch already exists on the remote, ask me before reusing it.
- Check that every ticket under "Depends on" is merged, meaning its code is on main. If one isn't, stop and tell me.

### 2. Build test-first
- Write the tests the ticket lists first. Run them and see them fail for the right reason, then implement until they pass.
- For every new guard, break it on purpose (invert or remove it), confirm at least one test goes red, then restore it. List these mutations in the PR body.
- Never weaken, skip, `.only`, or delete an existing test to get green. If an existing test looks wrong, stop and tell me why.

### 3. Security rules (non-negotiable)
- The model is untrusted. Security never depends on a prompt: enforce in code (tools, policy service, ledger).
- No secrets in git: no seeds, keys, tokens or DB URLs. `.env.example` holds variable names and obvious dummy values only. Each service reads only its own `.env`. Never print a secret value in logs, errors or test output.
- The agent process never holds a wallet seed, private key, DB credential or policy key. The model never sees a wallet address.
- Money is a decimal string (`Amount` from `@shucamoxa/shared`) end to end. No float maths on money: compare as integer cents or with a decimal library.
- Validate every input that crosses a process boundary with a Zod schema from `@shucamoxa/shared`. Add schemas there instead of ad hoc.
- Testnet only: code that signs or submits a transaction refuses any non-testnet endpoint or network ID.
- Internal services bind to 127.0.0.1 by default and require a bearer token per caller. Compare tokens in constant time.
- Owner-only actions (rules, suppliers, kill switch off, approval decisions) are never reachable with the agent token.
- Don't add a dependency without giving the reason in the PR. Prefer the spec's stack. Commit `pnpm-lock.yaml`.
- Never commit or `git add -f` these local-only paths: `CLAUDE.md`, `CLAUDE.local.md`, `.scratch/`, `docs/agents/`, `CONTEXT.md`, `docs/adr/`. Never create GitHub issues. Never remove them from `.git/info/exclude`.

### 4. Verify before finishing (all must pass, from the repo root)
- `pnpm install --frozen-lockfile` (update the lockfile first if dependencies changed)
- `pnpm typecheck`
- `pnpm test`
- `gitleaks detect --no-banner --redact` (once T02 has added it)
- `git ls-files | grep -E '(^|/)\.env' | grep -v '\.env\.example$'` prints nothing, and `git ls-files | grep -E 'CLAUDE|\.scratch/|docs/agents/'` prints nothing.

### 5. Squash, push, PR, merge
1. `git fetch origin && git rebase origin/main`. If anything changed, run step 4 again.
2. Squash to one commit: `git reset --soft origin/main`, then commit with a Conventional Commit subject `<type>(<scope>): <summary> (T<NN>)` and a body listing what changed and the tests added.
3. `git push -u origin <branch> --force-with-lease`
4. `gh pr create --base main --title "<commit subject>"` with a body of: Summary, Tests added, Mutations checked, Security notes, Follow-ups. Don't link or paste local ticket files.
5. `gh pr checks --watch`. If anything is red, fix it, squash again (step 2) and push with `--force-with-lease`. Skip this step until T02 has added CI.
6. Once green: `gh pr merge --squash --delete-branch`, then `git switch main && git pull --ff-only`.
7. In the local ticket file, set `Status: resolved` and append the PR URL and date under `## Comments`.

### 6. Report back
Reply with: the PR URL, what changed, tests added, mutations tried, anything you couldn't do and why, and follow-ups for the next ticket.

### 7. Usage limits and model fallback
- A usage limit shows up as an agent failing with a rate-limit error (HTTP 429, "You've hit your … limit · resets …"). Its work is saved in its worktree. Don't wait for the reset if a fallback model is available.
- **Fallback order:** default model (Opus), then `sonnet`, then `fable`. Never use `haiku` to build or review anything under `services/` or `packages/shared`. It is only for read-only lookups.
- **Switching model:** a resumed agent keeps its old model, so start a fresh agent with the Agent tool's `model` set to the fallback. Give it a handoff prompt with:
  - the ticket path and branch
  - the worktree path, last commit SHA and `git status`
  - the stopped agent's last message, saying what it was doing
  - "Read `git diff origin/main` first and continue from there; don't redo finished work."
- **Same bar on every model:** the workflow, security rules, mutation checks and step-4 checks are unchanged. The reviewer is always a different agent from the builder; they may run on the same model.
- **Record it locally only:** note the model used for each ticket in `.scratch/shucamoxa/overnight-log.md`. Never put a model name in commits or PR bodies, since there is no Claude authorship there.
- **If the fallback is also limited**, stop starting new agents and log what's in flight and the reset time in `overnight-log.md`. Then resume with SendMessage after the reset. Limits can be shared across models on a plan, so a fallback isn't guaranteed to work.
- **The main chat can't switch its own model.** If the orchestrator itself is limited, Cam picks another model in the app's model picker and says "continue". The new model reads this file and `overnight-log.md` to pick up the state.

### Stop and ask me before
- changing a contract in `packages/shared` that a merged ticket already uses
- touching another workstream's service beyond what the ticket says
- submitting a real testnet transaction, unless the ticket says to
- force-pushing `main`, or anything that conflicts with the spec
