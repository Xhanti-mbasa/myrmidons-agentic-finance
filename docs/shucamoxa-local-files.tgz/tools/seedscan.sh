#!/bin/sh
# Local stand-in for gitleaks: scan the diff between origin/main and HEAD for secrets.
# Usage: seedscan.sh [base]   (default base: origin/main). Exits 1 on any finding.
BASE="${1:-origin/main}"
ALLOW='services/agent/test/config.test.ts|\.gitleaks\.toml'
FILES=$(git diff --name-only "$BASE"...HEAD | grep -Ev "^($ALLOW)$" || true)
[ -z "$FILES" ] && { echo "seedscan: no changed files"; exit 0; }
FOUND=0
for f in $FILES; do
  [ -f "$f" ] || continue
  if grep -nE '(^|[^A-Za-z0-9])s[rpshnaf39wBUDNEGHJKLM4PQRST7VWXYZ2bcdeCg65jkm8oFqi1tuvAxyz]{28,30}([^A-Za-z0-9]|$)' "$f" >/dev/null 2>&1; then
    echo "seedscan: possible XRPL seed in $f"; FOUND=1; fi
  if grep -nE '(^|[^0-9A-Fa-f])(ED|00)?[0-9A-Fa-f]{64}([^0-9A-Fa-f]|$)' "$f" | grep -viE 'hash|txHash|GENESIS|prev_?hash|expected|sha256|known' >/dev/null 2>&1; then
    echo "seedscan: possible 64-hex key in $f (check it is a hash, not a key)"; FOUND=1; fi
  if grep -nE '(postgres(ql)?://[^ ]*:[^ ]*@|-----BEGIN [A-Z ]*PRIVATE KEY|eyJhbGciOi[A-Za-z0-9_-]{20,})' "$f" >/dev/null 2>&1; then
    echo "seedscan: credential-like string in $f"; FOUND=1; fi
done
TRACKED=$(git ls-files | grep -E '(^|/)\.env($|\.)' | grep -v '\.env\.example$'; git ls-files | grep -E '^(CLAUDE\.md|CLAUDE\.local\.md|CONTEXT\.md)$|^\.scratch/|^docs/agents/|^docs/adr/')
[ -n "$TRACKED" ] && { echo "seedscan: local-only or env files tracked:"; echo "$TRACKED"; FOUND=1; }
[ "$FOUND" = 0 ] && echo "seedscan: clean"
exit $FOUND
