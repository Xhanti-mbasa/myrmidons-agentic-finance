#!/bin/bash
# PR helper over the GitHub REST API (GraphQL is unavailable in this session).
#   pr.sh create <branch> <title> <bodyfile>   -> prints PR number
#   pr.sh checks <pr>                           -> waits for check runs on the PR head; exit 0 if all green (or none)
#   pr.sh merge <pr> <title>                    -> squash-merge, delete branch
set -euo pipefail
R=repos/Xhanti-mbasa/myrmidons-agentic-finance
GHBIN=$(command -v gh); gh() { env -u GH_TOKEN "$GHBIN" "$@"; }
case "$1" in
  create)
    gh api "$R/pulls" -f title="$3" -f head="$2" -f base=main -F body=@"$4" --jq .number ;;
  checks)
    sha=$(gh api "$R/pulls/$2" --jq .head.sha)
    for i in $(seq 1 90); do
      json=$(gh api "$R/commits/$sha/check-runs" --jq '[.check_runs[] | {name, status, conclusion}]')
      total=$(echo "$json" | jq length)
      pending=$(echo "$json" | jq '[.[] | select(.status != "completed")] | length')
      failed=$(echo "$json" | jq '[.[] | select(.status == "completed" and (.conclusion != "success" and .conclusion != "skipped" and .conclusion != "neutral"))] | length')
      if [ "$total" = 0 ] && [ "$i" -ge 6 ]; then echo "no checks"; exit 0; fi
      runs_pending=$(gh api "$R/actions/runs?head_sha=$sha" --jq '[.workflow_runs[] | select(.status != "completed")] | length')
      runs_total=$(gh api "$R/actions/runs?head_sha=$sha" --jq '.workflow_runs | length')
      if [ "$total" != 0 ] && [ "$pending" = 0 ] && [ "$runs_total" != 0 ] && [ "$runs_pending" = 0 ] && [ "$i" -ge 3 ]; then
        echo "$json" | jq -c '.[]'
        [ "$failed" = 0 ] && { echo "checks green"; exit 0; } || { echo "checks FAILED"; exit 1; }
      fi
      sleep 20
    done
    echo "checks timed out"; exit 2 ;;
  merge)
    sha=$(gh api "$R/pulls/$2" --jq .head.sha)
    ref=$(gh api "$R/pulls/$2" --jq .head.ref)
    git -C /home/claude/myrmidons-agentic-finance fetch -q origin "$ref"
    body=$(git -C /home/claude/myrmidons-agentic-finance log -1 --format=%b "$sha" | grep -viE '^(co-authored-by|claude-session):' || true)
    gh api -X PUT "$R/pulls/$2/merge" -f merge_method=squash -f sha="$sha" -f commit_title="$3 (#$2)" -f commit_message="$body" --jq .message
    (git -C /home/claude/myrmidons-agentic-finance push -q origin --delete "$ref" 2>/dev/null && echo "deleted $ref") || echo "branch $ref left on remote (delete not permitted here)" ;;
  *) echo "usage"; exit 64 ;;
esac
